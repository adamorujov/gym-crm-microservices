package com.influencer.epam_spring_tasks.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.influencer.epam_spring_tasks.dto.request.ChangePasswordRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeRegistrationRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainerListUpdateRequest;
import com.influencer.epam_spring_tasks.dto.request.TrainerRegistrationRequest;
import com.influencer.epam_spring_tasks.dto.request.TrainingAddRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TraineeResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerShortResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingTypeResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.facade.GymFacade;
import com.influencer.epam_spring_tasks.monitoring.metrics.GymMetricsService;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(GymController.class)
@Import({TestSecurityPermitAllConfig.class, com.influencer.epam_spring_tasks.exception.GlobalExceptionHandler.class})
class GymControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private GymFacade gymFacade;

    @MockBean
    private GymMetricsService gymMetricsService;

    @Test
    @DisplayName("POST /api/trainees should register trainee successfully")
    void registerTrainee_success() throws Exception {
        TraineeRegistrationRequest request = new TraineeRegistrationRequest();
        request.setFirstName("John");
        request.setLastName("Doe");
        request.setDateOfBirth(LocalDate.of(2000, 1, 1));
        request.setAddress("Baku");

        when(gymFacade.createTrainee(any())).thenReturn(new CredentialResponse("john.doe", "rawPass123"));

        mockMvc.perform(post("/api/trainees")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("john.doe"))
                .andExpect(jsonPath("$.password").value("rawPass123"));

        verify(gymMetricsService).incrementTraineeRegistrations();
    }

    @Test
    @DisplayName("POST /api/trainers should register trainer successfully")
    void registerTrainer_success() throws Exception {
        TrainerRegistrationRequest request = new TrainerRegistrationRequest();
        request.setFirstName("Jane");
        request.setLastName("Smith");
        request.setSpecialization("Yoga");

        when(gymFacade.createTrainer(any())).thenReturn(new CredentialResponse("jane.smith", "rawPass456"));

        mockMvc.perform(post("/api/trainers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("jane.smith"))
                .andExpect(jsonPath("$.password").value("rawPass456"));

        verify(gymMetricsService).incrementTrainerRegistrations();
    }

    @Test
    @DisplayName("GET /api/trainees/{username} should return trainee profile")
    void getTraineeProfile_success() throws Exception {
        when(gymFacade.getTraineeByUsername("john.doe")).thenReturn(new TraineeResponse());

        mockMvc.perform(get("/api/trainees/john.doe"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("GET /api/trainers/{username} should return trainer profile")
    void getTrainerProfile_success() throws Exception {
        when(gymFacade.getTrainerByUsername("jane.smith")).thenReturn(new TrainerResponse());

        mockMvc.perform(get("/api/trainers/jane.smith"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("PUT /api/trainees/{username} should update trainee profile")
    void updateTraineeProfile_success() throws Exception {
        UpdateTraineeRequest request = new UpdateTraineeRequest();
        request.setFirstName("Updated");

        when(gymFacade.updateTrainee(any())).thenReturn(new TraineeResponse());

        mockMvc.perform(put("/api/trainees/john.doe")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("PUT /api/trainers/{username} should update trainer profile")
    void updateTrainerProfile_success() throws Exception {
        UpdateTrainerRequest request = new UpdateTrainerRequest();
        request.setFirstName("Updated");

        when(gymFacade.updateTrainer(any())).thenReturn(new TrainerResponse());

        mockMvc.perform(put("/api/trainers/jane.smith")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("DELETE /api/trainees/{username} should delete trainee")
    void deleteTrainee_success() throws Exception {
        doNothing().when(gymFacade).deleteTraineeByUsername("john.doe");

        mockMvc.perform(delete("/api/trainees/john.doe"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("Trainee deleted"));
    }

    @Test
    @DisplayName("PUT /api/login should change password successfully")
    void changePassword_success() throws Exception {
        ChangePasswordRequest request = new ChangePasswordRequest();
        request.setUsername("john.doe");
        request.setOldPassword("oldPass");
        request.setNewPassword("newPass");

        doNothing().when(gymFacade).changeUserPassword(any());

        mockMvc.perform(put("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("Password changed"));
    }

    @Test
    @DisplayName("PUT /api/login should return 400 for invalid request")
    void changePassword_invalidRequest() throws Exception {
        ChangePasswordRequest request = new ChangePasswordRequest();
        request.setUsername("");
        request.setOldPassword("oldPass");
        request.setNewPassword("newPass");

        mockMvc.perform(put("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value("ERROR"))
                .andExpect(jsonPath("$.message").value("Invalid request"));
    }

    @Test
    @DisplayName("PUT /api/login should return 404 when user not found")
    void changePassword_userNotFound() throws Exception {
        ChangePasswordRequest request = new ChangePasswordRequest();
        request.setUsername("missing.user");
        request.setOldPassword("oldPass");
        request.setNewPassword("newPass");

        doThrow(new ValidationException("User not found")).when(gymFacade).changeUserPassword(any());

        mockMvc.perform(put("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value("ERROR"))
                .andExpect(jsonPath("$.message").value("User not found"));
    }

    @Test
    @DisplayName("PATCH /api/trainees/{username}/activate should activate trainee")
    void activateTrainee_success() throws Exception {
        doNothing().when(gymFacade).activateTrainee("john.doe");

        mockMvc.perform(patch("/api/trainees/john.doe/activate"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"));
    }

    @Test
    @DisplayName("PATCH /api/trainers/{username}/deactivate should deactivate trainer")
    void deactivateTrainer_success() throws Exception {
        doNothing().when(gymFacade).deactivateTrainer("jane.smith");

        mockMvc.perform(patch("/api/trainers/jane.smith/deactivate"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"));
    }

    @Test
    @DisplayName("GET /api/trainees/{username}/trainings should return trainee trainings")
    void getTraineeTrainings_success() throws Exception {
        when(gymFacade.getTraineeTrainings(any()))
                .thenReturn(List.of(new TrainingResponse()));

        mockMvc.perform(get("/api/trainees/john.doe/trainings"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("GET /api/trainers/{username}/trainings should return trainer trainings")
    void getTrainerTrainings_success() throws Exception {
        when(gymFacade.getTrainerTrainings(any()))
                .thenReturn(List.of(new TrainingResponse()));

        mockMvc.perform(get("/api/trainers/jane.smith/trainings"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("POST /api/trainings should add training")
    void addTraining_success() throws Exception {
        TrainingAddRequest request = new TrainingAddRequest();
        request.setTrainingName("Morning Training");
        request.setTrainerUsername("jane.smith");
        request.setTraineeUsername("john.doe");
        request.setTrainingDate(LocalDate.now());
        request.setTrainingDuration(60);

        when(gymFacade.addTraining(any())).thenReturn(new TrainingResponse());

        mockMvc.perform(post("/api/trainings")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk());

        verify(gymMetricsService).incrementTrainingsCreated();
    }

    @Test
    @DisplayName("GET /api/trainees/{username}/unassigned-trainers should return trainers")
    void getUnassignedTrainers_success() throws Exception {
        when(gymFacade.getUnassignedTrainersByTraineeUsername("john.doe"))
                .thenReturn(List.of(new TrainerShortResponse()));

        mockMvc.perform(get("/api/trainees/john.doe/unassigned-trainers"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("PUT /api/trainees/{username}/trainers should update trainer list")
    void updateTraineeTrainers_success() throws Exception {
        TraineeTrainerListUpdateRequest request = new TraineeTrainerListUpdateRequest();
        request.setTrainerUsernames(List.of("trainer1", "trainer2"));

        doNothing().when(gymFacade).updateTraineeTrainers(anyString(), anyList());

        mockMvc.perform(put("/api/trainees/john.doe/trainers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("OK"))
                .andExpect(jsonPath("$.message").value("Trainee trainer list updated"));

        verify(gymMetricsService).incrementTraineeTrainerUpdates();
    }

    @Test
    @DisplayName("PUT /api/trainees/{username}/trainers should return 400 for invalid request")
    void updateTraineeTrainers_invalidRequest() throws Exception {
        TraineeTrainerListUpdateRequest request = new TraineeTrainerListUpdateRequest();
        request.setTrainerUsernames(List.of());

        mockMvc.perform(put("/api/trainees/john.doe/trainers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.status").value("ERROR"))
                .andExpect(jsonPath("$.message").value("Invalid request"));
    }

    @Test
    @DisplayName("GET /api/training-types should return training types")
    void getTrainingTypes_success() throws Exception {
        when(gymFacade.getTrainingTypes()).thenReturn(List.of(new TrainingTypeResponse()));

        mockMvc.perform(get("/api/training-types"))
                .andExpect(status().isOk());
    }
}