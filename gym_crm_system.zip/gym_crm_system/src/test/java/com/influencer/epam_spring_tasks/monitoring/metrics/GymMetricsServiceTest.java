package com.influencer.epam_spring_tasks.monitoring.metrics;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;

class GymMetricsServiceTest {

    @Test
    void metrics_shouldBeRegisteredAndUpdated() {
        MeterRegistry registry = new SimpleMeterRegistry();
        GymMetricsService metricsService = new GymMetricsService(registry);

        metricsService.incrementTraineeRegistrations();
        metricsService.incrementTrainerRegistrations();
        metricsService.incrementSuccessfulLogins();
        metricsService.incrementFailedLogins();
        metricsService.incrementTrainingsCreated();
        metricsService.incrementTraineeTrainerUpdates();
        metricsService.recordAuthenticationDuration(1_000_000);

        assertNotNull(registry.find("gym.trainee.registrations").counter());
        assertNotNull(registry.find("gym.trainer.registrations").counter());
        assertNotNull(registry.find("gym.auth.login.success").counter());
        assertNotNull(registry.find("gym.auth.login.failure").counter());
        assertNotNull(registry.find("gym.training.created").counter());
        assertNotNull(registry.find("gym.trainee.trainer.update").counter());
        assertNotNull(registry.find("gym.auth.duration").timer());
    }
}