package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.Main;
import com.influencer.epam_spring_tasks.dto.request.AuthRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerShortResponse;
import com.influencer.epam_spring_tasks.support.TestDataFactory;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = Main.class)
@ActiveProfiles("local")
class TraineeTrainerAssignmentTest {

    @Autowired
    private TraineeService traineeService;

    @Autowired
    private TrainerService trainerService;

    @Test
    void unassignedTrainersAndUpdateTraineeTrainersShouldWork() {
        CredentialResponse traineeCreds = traineeService.createTrainee(
                TestDataFactory.trainee("Nina", "West", "Berlin")
        );

        CredentialResponse trainer1 = trainerService.createTrainer(
                TestDataFactory.trainer("Trainer", "One", "Cardio")
        );
        CredentialResponse trainer2 = trainerService.createTrainer(
                TestDataFactory.trainer("Trainer", "Two", "Cardio")
        );

        AuthRequest auth = new AuthRequest(traineeCreds.getUsername(), traineeCreds.getPassword());

        List<TrainerShortResponse> before = traineeService
                .getUnassignedTrainersByTraineeUsername(auth, traineeCreds.getUsername());
        Assertions.assertTrue(before.size() >= 2);

        traineeService.updateTraineeTrainers(
                auth,
                traineeCreds.getUsername(),
                List.of(trainer1.getUsername(), trainer2.getUsername())
        );

        List<TrainerShortResponse> after = traineeService
                .getUnassignedTrainersByTraineeUsername(auth, traineeCreds.getUsername());

        Assertions.assertTrue(after.size() <= before.size() - 2);
    }
}