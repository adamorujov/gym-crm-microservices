
package com.influencer.epam_spring_tasks.support;

import com.influencer.epam_spring_tasks.dto.request.CreateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTrainerRequest;

import java.time.LocalDate;

public final class TestDataFactory {

    private TestDataFactory() {
    }

    public static CreateTrainerRequest trainer(String firstName, String lastName, String specialization) {
        CreateTrainerRequest request = new CreateTrainerRequest();
        request.setFirstName(firstName);
        request.setLastName(lastName);
        request.setSpecializationTypeName(specialization);
        return request;
    }

    public static CreateTraineeRequest trainee(String firstName, String lastName, String address) {
        CreateTraineeRequest request = new CreateTraineeRequest();
        request.setFirstName(firstName);
        request.setLastName(lastName);
        request.setDateOfBirth(LocalDate.of(1998, 1, 1));
        request.setAddress(address);
        return request;
    }
}