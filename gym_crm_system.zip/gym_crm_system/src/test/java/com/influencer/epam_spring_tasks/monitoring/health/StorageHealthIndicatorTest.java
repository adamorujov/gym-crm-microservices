package com.influencer.epam_spring_tasks.monitoring.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.health.Status;

class StorageHealthIndicatorTest {

    @Test
    void health_up_whenPathExistsAndAccessible() throws Exception {
        Path tempDir = Files.createTempDirectory("gym-storage-test");
        StorageHealthIndicator indicator = new StorageHealthIndicator(tempDir.toString());

        Status status = indicator.health().getStatus();
        assertEquals(Status.UP, status);
    }

    @Test
    void health_down_whenPathDoesNotExist() {
        StorageHealthIndicator indicator = new StorageHealthIndicator("./non-existent-path-xyz-123");
        Status status = indicator.health().getStatus();

        assertEquals(Status.DOWN, status);
    }
}