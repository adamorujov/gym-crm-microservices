package com.influencer.epam_spring_tasks.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.influencer.epam_spring_tasks.dto.request.LoginRequest;
import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.model.User;
import com.influencer.epam_spring_tasks.service.AuthenticationService;
import com.influencer.epam_spring_tasks.service.BruteForceProtectionService;
import com.influencer.epam_spring_tasks.service.JwtService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuthController.class)
@Import({TestSecurityPermitAllConfig.class, com.influencer.epam_spring_tasks.exception.GlobalExceptionHandler.class})
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AuthenticationService authenticationService;

    @MockBean
    private BruteForceProtectionService bruteForceProtectionService;

    @MockBean
    private JwtService jwtService;

    @Test
    @DisplayName("POST /api/login should authenticate successfully and return bearer token")
    void login_success() throws Exception {
        LoginRequest request = new LoginRequest()
                .setUsername("john.doe")
                .setPassword("rawPassword");

        User user = new User()
                .setUsername("john.doe")
                .setPassword("encodedPassword")
                .setActive(true);

        doNothing().when(bruteForceProtectionService).checkBlocked("john.doe");
        when(authenticationService.requireAuthentication("john.doe", "rawPassword")).thenReturn(user);
        when(jwtService.generateToken(user)).thenReturn("jwt-token-123");

        mockMvc.perform(post("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.type").value("Bearer"))
                .andExpect(jsonPath("$.token").value("jwt-token-123"));

        verify(bruteForceProtectionService).checkBlocked("john.doe");
        verify(authenticationService).requireAuthentication("john.doe", "rawPassword");
        verify(bruteForceProtectionService).onSuccessfulLogin("john.doe");
        verify(bruteForceProtectionService, never()).onFailedLogin(anyString());
        verify(jwtService).generateToken(user);
    }

    @Test
    @DisplayName("POST /api/login should record failed attempt and return 401 for invalid credentials")
    void login_invalidCredentials() throws Exception {
        LoginRequest request = new LoginRequest()
                .setUsername("john.doe")
                .setPassword("wrongPassword");

        doNothing().when(bruteForceProtectionService).checkBlocked("john.doe");
        when(authenticationService.requireAuthentication("john.doe", "wrongPassword"))
                .thenThrow(new AuthenticationException("Invalid credentials"));

        mockMvc.perform(post("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value("ERROR"))
                .andExpect(jsonPath("$.message").value("Invalid credentials"));

        verify(bruteForceProtectionService).checkBlocked("john.doe");
        verify(authenticationService).requireAuthentication("john.doe", "wrongPassword");
        verify(bruteForceProtectionService).onFailedLogin("john.doe");
        verify(bruteForceProtectionService, never()).onSuccessfulLogin(anyString());
        verify(jwtService, never()).generateToken(any());
    }

    @Test
    @DisplayName("POST /api/login should return 401 when user is blocked")
    void login_blockedUser() throws Exception {
        LoginRequest request = new LoginRequest()
                .setUsername("blocked.user")
                .setPassword("somePassword");

        doThrow(new AuthenticationException("User is blocked until 2026-06-24T10:15:00"))
                .when(bruteForceProtectionService).checkBlocked("blocked.user");

        mockMvc.perform(post("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value("ERROR"))
                .andExpect(jsonPath("$.message").value("User is blocked until 2026-06-24T10:15:00"));

        verify(bruteForceProtectionService).checkBlocked("blocked.user");
        verify(authenticationService, never()).requireAuthentication(anyString(), anyString());
        verify(bruteForceProtectionService, never()).onFailedLogin(anyString());
        verify(bruteForceProtectionService, never()).onSuccessfulLogin(anyString());
        verify(jwtService, never()).generateToken(any());
    }

    @Test
    @DisplayName("POST /api/login should return 400 when username is blank")
    void login_blankUsername() throws Exception {
        LoginRequest request = new LoginRequest()
                .setUsername("")
                .setPassword("somePassword");

        mockMvc.perform(post("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());

        verify(bruteForceProtectionService, never()).checkBlocked(anyString());
        verify(authenticationService, never()).requireAuthentication(anyString(), anyString());
        verify(jwtService, never()).generateToken(any());
    }

    @Test
    @DisplayName("POST /api/login should return 400 when password is blank")
    void login_blankPassword() throws Exception {
        LoginRequest request = new LoginRequest()
                .setUsername("john.doe")
                .setPassword("");

        mockMvc.perform(post("/api/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());

        verify(bruteForceProtectionService, never()).checkBlocked(anyString());
        verify(authenticationService, never()).requireAuthentication(anyString(), anyString());
        verify(jwtService, never()).generateToken(any());
    }

    @Test
    @DisplayName("POST /api/logout should return 200")
    void logout_success() throws Exception {
        mockMvc.perform(post("/api/logout")
                        .header("Authorization", "Bearer jwt-token-123"))
                .andExpect(status().isOk());
    }

    @Test
    @DisplayName("POST /api/logout should return 200 even without authorization header")
    void logout_withoutAuthorizationHeader() throws Exception {
        mockMvc.perform(post("/api/logout"))
                .andExpect(status().isOk());
    }
}