package com.influencer.epam_spring_tasks.config;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.service.AuthenticationValidationService;
import com.influencer.epam_spring_tasks.service.impl.AuthenticationValidationServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.StringWriter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AuthenticationInterceptorTest {

    private AuthenticationValidationServiceImpl validationService;
    private AuthenticationInterceptor interceptor;
    private HttpServletRequest request;
    private HttpServletResponse response;

    @BeforeEach
    void setUp() {
        validationService = mock(AuthenticationValidationServiceImpl.class);
        interceptor = new AuthenticationInterceptor(validationService);
        request = mock(HttpServletRequest.class);
        response = mock(HttpServletResponse.class);
    }

    @Test
    void preHandle_allowsRequest_forRegistrationEndpoint() throws Exception {
        when(request.getRequestURI()).thenReturn("/api/trainees");
        when(request.getMethod()).thenReturn("POST");

        boolean result = interceptor.preHandle(request, response, null);
        assertTrue(result);
    }

    @Test
    void preHandle_allowsRequest_forActuatorEndpoint() throws Exception {
        when(request.getRequestURI()).thenReturn("/actuator/health");
        when(request.getMethod()).thenReturn("GET");

        boolean result = interceptor.preHandle(request, response, null);
        assertTrue(result);
    }

    @Test
    void preHandle_allowsRequest_whenValidCredentials() throws Exception {
        when(request.getRequestURI()).thenReturn("/api/trainees/john.doe");
        when(request.getMethod()).thenReturn("GET");
        when(request.getHeader("authUsername")).thenReturn("john.doe");
        when(request.getHeader("authPassword")).thenReturn("password123");
        doNothing().when(validationService).validateCredentials("john.doe", "password123");

        boolean result = interceptor.preHandle(request, response, null);
        assertTrue(result);
    }

    @Test
    void preHandle_deniesRequest_whenInvalidCredentials() throws Exception {
        when(request.getRequestURI()).thenReturn("/api/trainees/john.doe");
        when(request.getMethod()).thenReturn("GET");
        when(request.getHeader("authUsername")).thenReturn("john.doe");
        when(request.getHeader("authPassword")).thenReturn("wrongpass");
        doThrow(new AuthenticationException("Invalid credentials"))
                .when(validationService).validateCredentials("john.doe", "wrongpass");
        when(response.getWriter()).thenReturn(new java.io.PrintWriter(new StringWriter()));

        boolean result = interceptor.preHandle(request, response, null);
        assertFalse(result);
    }
}