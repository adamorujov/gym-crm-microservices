package com.influencer.epam_spring_tasks.monitoring.health;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import com.influencer.epam_spring_tasks.service.AuthenticationService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.actuate.health.Status;

class AuthenticationHealthIndicatorTest {

    @Test
    void health_up_whenServiceBeanAvailable() {
        AuthenticationService authService = mock(AuthenticationService.class);
        AuthenticationHealthIndicator indicator = new AuthenticationHealthIndicator(authService);

        assertEquals(Status.UP, indicator.health().getStatus());
    }
}