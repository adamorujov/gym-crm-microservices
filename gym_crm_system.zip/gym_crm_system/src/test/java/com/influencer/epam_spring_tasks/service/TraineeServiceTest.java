package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.Main;
import com.influencer.epam_spring_tasks.dto.request.AuthRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TraineeResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.support.TestDataFactory;
import java.time.LocalDate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(classes = Main.class)
@ActiveProfiles("local")
class TraineeServiceTest {

    @Autowired
    private TraineeService traineeService;

    @Test
    void createAndGetTraineeByUsername() {
        CredentialResponse creds = traineeService.createTrainee(
                TestDataFactory.trainee("Alice", "Green", "Boston")
        );

        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());
        TraineeResponse trainee = traineeService.getTraineeByUsername(auth, creds.getUsername());

        Assertions.assertEquals("Alice", trainee.getFirstName());
        Assertions.assertEquals("Green", trainee.getLastName());
        Assertions.assertEquals(creds.getUsername(), trainee.getUsername());
    }

    @Test
    void updateTraineeShouldApplyFields() {
        CredentialResponse creds = traineeService.createTrainee(
                TestDataFactory.trainee("Tom", "Lee", "Old Address")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        UpdateTraineeRequest update = new UpdateTraineeRequest();
        update.setTargetUsername(creds.getUsername());
        update.setAddress("New Address");
        update.setFirstName("Thomas");

        TraineeResponse updated = traineeService.updateTrainee(auth, update);

        Assertions.assertEquals("Thomas", updated.getFirstName());
        Assertions.assertEquals("New Address", updated.getAddress());
    }

    @Test
    void deactivateThenDeactivateAgainShouldThrowNonIdempotentError() {
        CredentialResponse creds = traineeService.createTrainee(
                TestDataFactory.trainee("Mike", "Jones", "LA")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        traineeService.deactivateTrainee(auth, creds.getUsername());

        assertThrows(ValidationException.class,
                () -> traineeService.deactivateTrainee(auth, creds.getUsername()));
    }

    @Test
    void activateThenActivateAgainShouldThrowNonIdempotentError() {
        CredentialResponse creds = traineeService.createTrainee(
                TestDataFactory.trainee("Kate", "Stone", "NY")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        traineeService.deactivateTrainee(auth, creds.getUsername());
        traineeService.activateTrainee(auth, creds.getUsername());

        assertThrows(ValidationException.class,
                () -> traineeService.activateTrainee(auth, creds.getUsername()));
    }

    @Test
    void changePasswordShouldRequireNewPasswordAuthentication() {
        CredentialResponse creds = traineeService.createTrainee(
                TestDataFactory.trainee("Liam", "Scott", "TX")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        traineeService.changeTraineePassword(auth, creds.getUsername(), "NewPass1234");

        AuthRequest newAuth = new AuthRequest(creds.getUsername(), "NewPass1234");
        TraineeResponse trainee = traineeService.getTraineeByUsername(newAuth, creds.getUsername());

        Assertions.assertEquals(creds.getUsername(), trainee.getUsername());
    }

    @Test
    void deleteTraineeByUsername_success_thenNotFound() {
        CreateTraineeRequest req = new CreateTraineeRequest();
        req.setFirstName("Delete");
        req.setLastName("Me");
        req.setDateOfBirth(LocalDate.of(1995, 1, 1));
        req.setAddress("Addr");

        CredentialResponse created = traineeService.createTrainee(req);
        AuthRequest auth = new AuthRequest(created.getUsername(), created.getPassword());

        TraineeResponse beforeDelete = traineeService.getTraineeByUsername(auth, created.getUsername());
        assertNotNull(beforeDelete);

        traineeService.deleteTraineeByUsername(auth, created.getUsername());

        ValidationException ex = assertThrows(
                ValidationException.class,
                () -> traineeService.getTraineeByUsername(auth, created.getUsername())
        );
        assertTrue(ex.getMessage().contains("not found"));
    }
}