package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.Main;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.support.TestDataFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = Main.class)
@ActiveProfiles("local")
class AuthenticationServiceTest {

    @Autowired
    private TrainerService trainerService;

    @Autowired
    private AuthenticationService authenticationService;

    @Test
    void authenticateShouldReturnTrueForValidCredentials() {
        CredentialResponse creds = trainerService.createTrainer(
                TestDataFactory.trainer("Emma", "Brown", "Cardio")
        );

        boolean result = authenticationService.authenticate(creds.getUsername(), creds.getPassword());
        Assertions.assertTrue(result);
    }

    @Test
    void authenticateShouldReturnFalseForInvalidCredentials() {
        CredentialResponse creds = trainerService.createTrainer(
                TestDataFactory.trainer("John", "Miller", "Cardio")
        );

        boolean result = authenticationService.authenticate(creds.getUsername(), "wrongPassword");
        Assertions.assertFalse(result);
    }

    @Test
    void requireAuthenticationShouldThrowForInvalidCredentials() {
        CredentialResponse creds = trainerService.createTrainer(
                TestDataFactory.trainer("Mark", "White", "Cardio")
        );

        Assertions.assertThrows(
                AuthenticationException.class,
                () -> authenticationService.requireAuthentication(creds.getUsername(), "bad")
        );
    }
}