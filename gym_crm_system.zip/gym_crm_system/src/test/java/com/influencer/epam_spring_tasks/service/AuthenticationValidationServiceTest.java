package com.influencer.epam_spring_tasks.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.service.impl.AuthenticationValidationServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AuthenticationValidationServiceTest {

    private AuthenticationService authenticationService;
    private AuthenticationValidationService validationService;

    @BeforeEach
    void setUp() {
        authenticationService = mock(AuthenticationService.class);
        validationService = new AuthenticationValidationServiceImpl(authenticationService);
    }

    @Test
    void validateCredentials_success_whenCredentialsValid() {
        when(authenticationService.authenticate("john.doe", "password123")).thenReturn(true);

        assertDoesNotThrow(() -> validationService.validateCredentials("john.doe", "password123"));
    }

    @Test
    void validateCredentials_throwsException_whenCredentialsInvalid() {
        when(authenticationService.authenticate("john.doe", "wrongpassword")).thenReturn(false);

        assertThrows(AuthenticationException.class,
                () -> validationService.validateCredentials("john.doe", "wrongpassword"));
    }

    @Test
    void validateCredentials_throwsException_whenUsernameEmpty() {
        assertThrows(AuthenticationException.class,
                () -> validationService.validateCredentials("", "password123"));
    }

    @Test
    void validateCredentials_throwsException_whenPasswordEmpty() {
        assertThrows(AuthenticationException.class,
                () -> validationService.validateCredentials("john.doe", ""));
    }

    @Test
    void validateCredentials_throwsException_whenUsernameNull() {
        assertThrows(AuthenticationException.class,
                () -> validationService.validateCredentials(null, "password123"));
    }
}