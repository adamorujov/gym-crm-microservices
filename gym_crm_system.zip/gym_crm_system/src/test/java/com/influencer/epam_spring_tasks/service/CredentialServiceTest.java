package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.Main;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.support.TestDataFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = Main.class)
@ActiveProfiles("local")
class CredentialServiceTest {

    @Autowired
    private TrainerService trainerService;

    @Autowired
    private UserCredentialService credentialService;

    @Test
    void generatedPasswordShouldHaveLength10() {
        String password = credentialService.generatePassword();
        Assertions.assertEquals(10, password.length());
    }

    @Test
    void usernameShouldGetNumericSuffixWhenDuplicateExists() {
        CredentialResponse first = trainerService.createTrainer(
                TestDataFactory.trainer("John", "Smith", "Cardio")
        );
        CredentialResponse second = trainerService.createTrainer(
                TestDataFactory.trainer("John", "Smith", "Cardio")
        );

        Assertions.assertNotEquals(first.getUsername(), second.getUsername());
        Assertions.assertTrue(second.getUsername().startsWith("john.smith"));
    }
}