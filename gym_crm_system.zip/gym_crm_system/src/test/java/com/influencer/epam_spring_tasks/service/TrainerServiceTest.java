package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.Main;
import com.influencer.epam_spring_tasks.dto.request.AuthRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.support.TestDataFactory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(classes = Main.class)
@ActiveProfiles("local")
class TrainerServiceTest {

    @Autowired
    private TrainerService trainerService;

    @Autowired
    private AuthenticationService authenticationService;

    @Test
    void createAndGetTrainerByUsername() {
        CredentialResponse creds = trainerService.createTrainer(
                TestDataFactory.trainer("Emma", "Brown", "Cardio")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        TrainerResponse trainer = trainerService.getTrainerByUsername(auth, creds.getUsername());

        Assertions.assertEquals("Emma", trainer.getFirstName());
        Assertions.assertEquals("Brown", trainer.getLastName());
        Assertions.assertEquals("Cardio", trainer.getSpecialization());
    }

    @Test
    void updateTrainerShouldApplyFields() {
        CredentialResponse creds = trainerService.createTrainer(
                TestDataFactory.trainer("David", "Hill", "Cardio")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        UpdateTrainerRequest update = new UpdateTrainerRequest();
        update.setTargetUsername(creds.getUsername());
        update.setFirstName("Dave");

        TrainerResponse updated = trainerService.updateTrainer(auth, update);
        Assertions.assertEquals("Dave", updated.getFirstName());
    }

    @Test
    void deactivateThenDeactivateAgainShouldThrow() {
        CredentialResponse creds = trainerService.createTrainer(
                TestDataFactory.trainer("Mark", "Taylor", "Cardio")
        );
        AuthRequest auth = new AuthRequest(creds.getUsername(), creds.getPassword());

        trainerService.deactivateTrainer(auth, creds.getUsername());

        assertThrows(
                ValidationException.class,
                () -> trainerService.deactivateTrainer(auth, creds.getUsername())
        );
    }

    @Test
    void changeTrainerPassword_success_andAuthenticateWithNewPassword() {
        CreateTrainerRequest req = new CreateTrainerRequest();
        req.setFirstName("Pass");
        req.setLastName("Changer");
        req.setSpecializationTypeName("Cardio");

        CredentialResponse created = trainerService.createTrainer(req);

        AuthRequest authOld = new AuthRequest(created.getUsername(), created.getPassword());
        String newPassword = "NewPass123";

        trainerService.changeTrainerPassword(authOld, created.getUsername(), newPassword);

        assertFalse(authenticationService.authenticate(created.getUsername(), created.getPassword()));
        assertTrue(authenticationService.authenticate(created.getUsername(), newPassword));
    }

    @Test
    void activateTrainer_nonIdempotent_secondCallThrows() {
        CreateTrainerRequest req = new CreateTrainerRequest();
        req.setFirstName("Active");
        req.setLastName("Twice");
        req.setSpecializationTypeName("Cardio");

        CredentialResponse created = trainerService.createTrainer(req);
        AuthRequest auth = new AuthRequest(created.getUsername(), created.getPassword());

        trainerService.deactivateTrainer(auth, created.getUsername());
        trainerService.activateTrainer(auth, created.getUsername());

        ValidationException ex = assertThrows(
                ValidationException.class,
                () -> trainerService.activateTrainer(auth, created.getUsername())
        );
        assertTrue(ex.getMessage().contains("already active"));
    }
}