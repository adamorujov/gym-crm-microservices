package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.Main;
import com.influencer.epam_spring_tasks.dto.request.AuthRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.TrainerTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.TrainingAddRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.support.TestDataFactory;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = Main.class)
@ActiveProfiles("local")
class TrainingServiceTest {

    @Autowired
    private TraineeService traineeService;

    @Autowired
    private TrainerService trainerService;

    @Autowired
    private TrainingService trainingService;

    @Test
    void addTrainingAndFilterByTraineeCriteria() {
        CredentialResponse trainerCreds = trainerService.createTrainer(
                TestDataFactory.trainer("Emma", "Brown", "Cardio")
        );
        CredentialResponse traineeCreds = traineeService.createTrainee(
                TestDataFactory.trainee("John", "Smith", "Boston")
        );

        AuthRequest auth = new AuthRequest(traineeCreds.getUsername(), traineeCreds.getPassword());

        TrainingAddRequest add = new TrainingAddRequest();
        add.setTraineeUsername(traineeCreds.getUsername());
        add.setTrainerUsername(trainerCreds.getUsername());
        add.setTrainingName("Morning Session");
        add.setTrainingTypeName("Cardio");
        add.setTrainingDate(LocalDate.now());
        add.setTrainingDuration(60);

        TrainingResponse added = trainingService.addTraining(auth, add);
        Assertions.assertNotNull(added.getTrainingName());

        TraineeTrainingFilter filter = new TraineeTrainingFilter();
        filter.setTraineeUsername(traineeCreds.getUsername());
        filter.setFromDate(LocalDate.now().minusDays(1));
        filter.setToDate(LocalDate.now().plusDays(1));

        List<TrainingResponse> list = traineeService.getTraineeTrainings(auth, filter);
        Assertions.assertFalse(list.isEmpty());
    }

    @Test
    void filterByTrainerCriteriaShouldReturnRecords() {
        CredentialResponse trainerCreds = trainerService.createTrainer(
                TestDataFactory.trainer("Mike", "Jordan", "Cardio")
        );
        CredentialResponse traineeCreds = traineeService.createTrainee(
                TestDataFactory.trainee("Alice", "Stone", "NY")
        );

        AuthRequest auth = new AuthRequest(trainerCreds.getUsername(), trainerCreds.getPassword());

        TrainingAddRequest add = new TrainingAddRequest();
        add.setTraineeUsername(traineeCreds.getUsername());
        add.setTrainerUsername(trainerCreds.getUsername());
        add.setTrainingName("Noon Session");
        add.setTrainingTypeName("Cardio");
        add.setTrainingDate(LocalDate.now());
        add.setTrainingDuration(45);

        trainingService.addTraining(auth, add);

        TrainerTrainingFilter filter = new TrainerTrainingFilter();
        filter.setTrainerUsername(trainerCreds.getUsername());
        filter.setFromDate(LocalDate.now().minusDays(1));
        filter.setToDate(LocalDate.now().plusDays(1));

        List<TrainingResponse> list = trainerService.getTrainerTrainings(auth, filter);
        Assertions.assertFalse(list.isEmpty());
    }
}