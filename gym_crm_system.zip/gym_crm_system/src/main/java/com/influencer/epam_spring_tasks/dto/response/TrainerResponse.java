
package com.influencer.epam_spring_tasks.dto.response;

import java.util.ArrayList;
import java.util.List;

public class TrainerResponse {
    private Long userId;
    private String firstName;
    private String lastName;
    private String username;
    private Boolean isActive;
    private String specialization;
    private List<TraineeShortResponse> trainees = new ArrayList<>();

    public Long getUserId() {
        return userId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public String getSpecialization() {
        return specialization;
    }

    public List<TraineeShortResponse> getTrainees() {
        return trainees;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setIsActive(Boolean active) {
        isActive = active;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public void setTrainees(List<TraineeShortResponse> trainees) {
        this.trainees = trainees;
    }
}