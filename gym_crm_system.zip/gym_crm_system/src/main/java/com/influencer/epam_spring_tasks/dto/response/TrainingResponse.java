
package com.influencer.epam_spring_tasks.dto.response;

import java.time.LocalDate;

public class TrainingResponse {
    private String trainingName;
    private String trainingType;
    private LocalDate trainingDate;
    private Integer trainingDuration;
    private String trainerName;
    private String traineeName;

    public String getTrainingName() {
        return trainingName;
    }

    public TrainingResponse setTrainingName(String trainingName) {
        this.trainingName = trainingName;
        return this;
    }

    public String getTrainingType() {
        return trainingType;
    }

    public TrainingResponse setTrainingType(String trainingType) {
        this.trainingType = trainingType;
        return this;
    }

    public LocalDate getTrainingDate() {
        return trainingDate;
    }

    public TrainingResponse setTrainingDate(LocalDate trainingDate) {
        this.trainingDate = trainingDate;
        return this;
    }

    public Integer getTrainingDuration() {
        return trainingDuration;
    }

    public TrainingResponse setTrainingDuration(Integer trainingDuration) {
        this.trainingDuration = trainingDuration;
        return this;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public TrainingResponse setTrainerName(String trainerName) {
        this.trainerName = trainerName;
        return this;
    }

    public String getTraineeName() {
        return traineeName;
    }

    public TrainingResponse setTraineeName(String traineeName) {
        this.traineeName = traineeName;
        return this;
    }

}