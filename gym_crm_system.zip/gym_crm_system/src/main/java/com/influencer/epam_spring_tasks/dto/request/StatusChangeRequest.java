package com.influencer.epam_spring_tasks.dto.request;

public class StatusChangeRequest {
    private String username;
    private Boolean isActive;

    public String getUsername() {
        return username;
    }

    public StatusChangeRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public Boolean getActive() {
        return isActive;
    }

    public StatusChangeRequest setActive(Boolean active) {
        isActive = active;
        return this;
    }
}
