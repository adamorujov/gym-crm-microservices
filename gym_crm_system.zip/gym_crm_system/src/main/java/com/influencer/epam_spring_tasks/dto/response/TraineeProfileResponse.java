package com.influencer.epam_spring_tasks.dto.response;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TraineeProfileResponse {
    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;
    private String address;
    private Boolean isActive;
    private List<TrainerShortResponse> trainers = new ArrayList<>();

    public String getFirstName() {
        return firstName;
    }

    public TraineeProfileResponse setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public TraineeProfileResponse setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public TraineeProfileResponse setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public TraineeProfileResponse setAddress(String address) {
        this.address = address;
        return this;
    }

    public Boolean getActive() {
        return isActive;
    }

    public TraineeProfileResponse setActive(Boolean active) {
        isActive = active;
        return this;
    }

    public List<TrainerShortResponse> getTrainers() {
        return trainers;
    }

    public TraineeProfileResponse setTrainers(List<TrainerShortResponse> trainers) {
        this.trainers = trainers;
        return this;
    }
}
