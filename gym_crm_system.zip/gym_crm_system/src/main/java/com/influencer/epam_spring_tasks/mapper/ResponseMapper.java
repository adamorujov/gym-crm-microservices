
package com.influencer.epam_spring_tasks.mapper;

import com.influencer.epam_spring_tasks.dto.response.*;
import com.influencer.epam_spring_tasks.model.Trainee;
import com.influencer.epam_spring_tasks.model.Trainer;
import com.influencer.epam_spring_tasks.model.Training;
import com.influencer.epam_spring_tasks.model.TrainingType;

import java.util.List;

public interface ResponseMapper {
    TraineeResponse toTraineeResponse(Trainee entity);
    TrainerResponse toTrainerResponse(Trainer entity);
    TrainingResponse toTrainingResponse(Training entity);
    TrainerShortResponse toTrainerShortResponse(Trainer entity);
    TraineeShortResponse toTraineeShortResponse(Trainee entity);

    List<TrainingResponse> toTrainingResponses(List<Training> entities);
    List<TrainerShortResponse> toTrainerShortResponses(List<Trainer> entities);

    List<TrainingTypeResponse> toTrainingTypeResponses(List<TrainingType> types);
}