package com.influencer.epam_spring_tasks.monitoring.health;


import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;

@Component("databaseHealth")
public class DatabaseHealthIndicator implements HealthIndicator {

    private final DataSource dataSource;

    public DatabaseHealthIndicator(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public Health health() {
        try (Connection connection = dataSource.getConnection()){
            boolean valid = connection.isValid(2);
            if (valid) {
                return Health.up()
                        .withDetail("database", "reachable")
                        .withDetail("validationTimeoutSec", 2)
                        .build();
            }
            return Health.down()
                    .withDetail("database", "connection not valid")
                    .build();
        } catch (Exception ex) {
            return Health.down(ex)
                    .withDetail("database", "unreachable")
                    .build();
        }
    }
}
