
package com.influencer.epam_spring_tasks.dto.request;

public class UpdateTrainerRequest {
    private String targetUsername;
    private String firstName;
    private String lastName;
    private String specializationTypeName;
    private Boolean isActive;

    public String getTargetUsername() {
        return targetUsername;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSpecializationTypeName() {
        return specializationTypeName;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setTargetUsername(String targetUsername) {
        this.targetUsername = targetUsername;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setSpecializationTypeName(String specializationTypeName) {
        this.specializationTypeName = specializationTypeName;
    }

    public void setIsActive(Boolean active) {
        isActive = active;
    }
}