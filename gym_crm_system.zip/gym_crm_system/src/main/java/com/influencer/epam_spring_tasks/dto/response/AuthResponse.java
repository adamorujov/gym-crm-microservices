package com.influencer.epam_spring_tasks.dto.response;

public class AuthResponse {
    private String status;
    private String message;

    public AuthResponse() {

    }

    public AuthResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public AuthResponse setStatus(String status) {
        this.status = status;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public AuthResponse setMessage(String message) {
        this.message = message;
        return this;
    }
}
