package com.influencer.epam_spring_tasks.dto.response;

import java.util.ArrayList;
import java.util.List;

public class TrainerProfileResponse {
    private String firstName;
    private String lastName;
    private String specialization;
    private Boolean isActive;
    private List<TraineeShortResponse> trainees = new ArrayList<>();

    public String getFirstName() {
        return firstName;
    }

    public TrainerProfileResponse setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public TrainerProfileResponse setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getSpecialization() {
        return specialization;
    }

    public TrainerProfileResponse setSpecialization(String specialization) {
        this.specialization = specialization;
        return this;
    }

    public Boolean getActive() {
        return isActive;
    }

    public TrainerProfileResponse setActive(Boolean active) {
        isActive = active;
        return this;
    }

    public List<TraineeShortResponse> getTrainees() {
        return trainees;
    }

    public TrainerProfileResponse setTrainees(List<TraineeShortResponse> trainees) {
        this.trainees = trainees;
        return this;
    }
}
