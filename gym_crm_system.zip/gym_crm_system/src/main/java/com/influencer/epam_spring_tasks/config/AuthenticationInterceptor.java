package com.influencer.epam_spring_tasks.config;

import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.service.impl.AuthenticationValidationServiceImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthenticationInterceptor implements HandlerInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationInterceptor.class);

    private final AuthenticationValidationServiceImpl authValidationService;

    public AuthenticationInterceptor(AuthenticationValidationServiceImpl authValidationService) {
        this.authValidationService = authValidationService;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        String requestUri = request.getRequestURI();
        String method = request.getMethod();

        logger.debug("Intercepting request: {} {}", method, requestUri);

        // Public endpoints
        if (isPublicEndpoint(requestUri, method)) {
            logger.debug("Skipping authentication for public endpoint: {} {}", method, requestUri);
            return true;
        }

        // Actuator endpoints
        if (isActuatorEndpoint(requestUri)) {
            logger.debug("Skipping authentication for actuator endpoint: {}", requestUri);
            return true;
        }

        // Protected endpoints: require auth headers
        String authUsername = request.getHeader("authUsername");
        String authPassword = request.getHeader("authPassword");

        try {
            authValidationService.validateCredentials(authUsername, authPassword);
            logger.debug("Authentication validated for endpoint: {}", requestUri);
            return true;
        } catch (AuthenticationException ex) {
            logger.warn("Authentication failed for endpoint {}: {}", requestUri, ex.getMessage());

            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.setContentType("application/json");
            response.getWriter().write("{\"status\":\"ERROR\",\"message\":\"" + escapeJson(ex.getMessage()) + "\"}");
            return false;
        }
    }

    private boolean isPublicEndpoint(String uri, String method) {
        return isRegisterTraineeEndpoint(uri, method)
                || isRegisterTrainerEndpoint(uri, method)
                || isLoginEndpoint(uri, method)
                || isChangePasswordEndpoint(uri, method);
    }

    private boolean isRegisterTraineeEndpoint(String uri, String method) {
        return "POST".equalsIgnoreCase(method) && uri.matches("^/api/trainees/?$");
    }

    private boolean isRegisterTrainerEndpoint(String uri, String method) {
        return "POST".equalsIgnoreCase(method) && uri.matches("^/api/trainers/?$");
    }

    private boolean isLoginEndpoint(String uri, String method) {
        return "GET".equalsIgnoreCase(method) && uri.matches("^/api/login/?$");
    }

    private boolean isChangePasswordEndpoint(String uri, String method) {
        return "PUT".equalsIgnoreCase(method) && uri.matches("^/api/login/?$");
    }

    private boolean isActuatorEndpoint(String uri) {
        return uri != null && uri.startsWith("/actuator");
    }

    private String escapeJson(String value) {
        if (value == null) {
            return "Authentication failed";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}