package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.dto.request.TrainingAddRequest;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;

public interface TrainingService {
    TrainingResponse addTraining(TrainingAddRequest request);
}