
package com.influencer.epam_spring_tasks.dto.request;

import java.time.LocalDate;

public class TraineeTrainingFilter {
    private String traineeUsername;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String trainerName;
    private String trainingTypeName;

    public String getTraineeUsername() {
        return traineeUsername;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public String getTrainingTypeName() {
        return trainingTypeName;
    }

    public void setTraineeUsername(String traineeUsername) {
        this.traineeUsername = traineeUsername;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    public void setTrainerName(String trainerName) {
        this.trainerName = trainerName;
    }

    public void setTrainingTypeName(String trainingTypeName) {
        this.trainingTypeName = trainingTypeName;
    }
}