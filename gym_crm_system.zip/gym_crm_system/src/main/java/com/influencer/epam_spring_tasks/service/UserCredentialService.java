package com.influencer.epam_spring_tasks.service;

public interface UserCredentialService {
    String generateUsername(String firstName, String lastName);
    String generatePassword();
}
