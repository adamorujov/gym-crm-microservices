package com.influencer.epam_spring_tasks.dto.workload;

import java.time.LocalDate;

public class TrainerWorkloadRequest {

    private String trainerUsername;
    private String trainerFirstName;
    private String trainerLastName;
    private Boolean isActive;
    private LocalDate trainingDate;
    private Integer trainingDuration;
    private String actionType;

    public String getTrainerUsername() {
        return trainerUsername;
    }

    public TrainerWorkloadRequest setTrainerUsername(String trainerUsername) {
        this.trainerUsername = trainerUsername;
        return this;
    }

    public String getTrainerFirstName() {
        return trainerFirstName;
    }

    public TrainerWorkloadRequest setTrainerFirstName(String trainerFirstName) {
        this.trainerFirstName = trainerFirstName;
        return this;
    }

    public String getTrainerLastName() {
        return trainerLastName;
    }

    public TrainerWorkloadRequest setTrainerLastName(String trainerLastName) {
        this.trainerLastName = trainerLastName;
        return this;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public TrainerWorkloadRequest setIsActive(Boolean isActive) {
        this.isActive = isActive;
        return this;
    }

    public LocalDate getTrainingDate() {
        return trainingDate;
    }

    public TrainerWorkloadRequest setTrainingDate(LocalDate trainingDate) {
        this.trainingDate = trainingDate;
        return this;
    }

    public Integer getTrainingDuration() {
        return trainingDuration;
    }

    public TrainerWorkloadRequest setTrainingDuration(Integer trainingDuration) {
        this.trainingDuration = trainingDuration;
        return this;
    }

    public String getActionType() {
        return actionType;
    }

    public TrainerWorkloadRequest setActionType(String actionType) {
        this.actionType = actionType;
        return this;
    }
}

