package com.influencer.epam_spring_tasks.monitoring.health;

import com.influencer.epam_spring_tasks.repository.UserRepository;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component("authenticationHealth")
public class AuthenticationHealthIndicator implements HealthIndicator {

    private final UserRepository userRepository;

    public AuthenticationHealthIndicator(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Health health() {
        try {
            userRepository.count();
            return Health.up().withDetail("authentication", "available").build();
        } catch (Exception ex) {
            return Health.down(ex).withDetail("authentication", "unavailable").build();
        }
    }
}