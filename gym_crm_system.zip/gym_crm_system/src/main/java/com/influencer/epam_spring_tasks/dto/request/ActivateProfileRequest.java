package com.influencer.epam_spring_tasks.dto.request;

public class ActivateProfileRequest {
    private String username;
    private Boolean isActive;

    public String getUsername() {
        return username;
    }

    public ActivateProfileRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public Boolean getActive() {
        return isActive;
    }

    public ActivateProfileRequest setActive(Boolean active) {
        isActive = active;
        return this;
    }
}
