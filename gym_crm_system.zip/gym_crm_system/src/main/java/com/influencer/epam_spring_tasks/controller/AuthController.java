package com.influencer.epam_spring_tasks.controller;

import com.influencer.epam_spring_tasks.dto.request.LoginRequest;
import com.influencer.epam_spring_tasks.dto.response.LoginResponse;
import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.model.User;
import com.influencer.epam_spring_tasks.service.AuthenticationService;
import com.influencer.epam_spring_tasks.service.BruteForceProtectionService;
import com.influencer.epam_spring_tasks.service.JwtService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AuthController {

    private final AuthenticationService authenticationService;
    private final BruteForceProtectionService bruteForceProtectionService;
    private final JwtService jwtService;

    public AuthController(
            AuthenticationService authenticationService,
            BruteForceProtectionService bruteForceProtectionService,
            JwtService jwtService
    ) {
        this.authenticationService = authenticationService;
        this.bruteForceProtectionService = bruteForceProtectionService;
        this.jwtService = jwtService;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        bruteForceProtectionService.checkBlocked(request.getUsername());

        try {
            User user = authenticationService.requireAuthentication(request.getUsername(), request.getPassword());
            bruteForceProtectionService.onSuccessfulLogin(request.getUsername());

            String token = jwtService.generateToken(user);
            return ResponseEntity.ok(new LoginResponse("Bearer", token));
        } catch (AuthenticationException ex) {
            bruteForceProtectionService.onFailedLogin(request.getUsername());
            throw ex;
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(@RequestHeader(name = "Authorization", required = false) String authorization) {
        // Stateless JWT logout usually means client deletes token.
        // If you want server-side logout, add a token blacklist store.
        return ResponseEntity.ok().build();
    }
}