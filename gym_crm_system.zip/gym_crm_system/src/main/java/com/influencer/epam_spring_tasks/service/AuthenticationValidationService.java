package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.exception.AuthenticationException;

public interface AuthenticationValidationService {
    void  validateCredentials(String username, String password) throws AuthenticationException;
}
