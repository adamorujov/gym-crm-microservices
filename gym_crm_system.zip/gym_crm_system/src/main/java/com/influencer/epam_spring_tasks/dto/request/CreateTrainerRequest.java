
package com.influencer.epam_spring_tasks.dto.request;

public class CreateTrainerRequest {
    private String firstName;
    private String lastName;
    private String specializationTypeName;

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSpecializationTypeName() {
        return specializationTypeName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setSpecializationTypeName(String specializationTypeName) {
        this.specializationTypeName = specializationTypeName;
    }
}