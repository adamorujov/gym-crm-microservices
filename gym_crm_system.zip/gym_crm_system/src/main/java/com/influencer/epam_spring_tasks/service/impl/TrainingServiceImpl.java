package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.client.TrainerWorkloadClient;
import com.influencer.epam_spring_tasks.dto.request.TrainingAddRequest;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.dto.workload.TrainerWorkloadRequest;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.mapper.ResponseMapper;
import com.influencer.epam_spring_tasks.model.Trainee;
import com.influencer.epam_spring_tasks.model.Trainer;
import com.influencer.epam_spring_tasks.model.Training;
import com.influencer.epam_spring_tasks.model.TrainingType;
import com.influencer.epam_spring_tasks.repository.TraineeRepository;
import com.influencer.epam_spring_tasks.repository.TrainerRepository;
import com.influencer.epam_spring_tasks.repository.TrainingRepository;
import com.influencer.epam_spring_tasks.repository.TrainingTypeRepository;
import com.influencer.epam_spring_tasks.service.TrainingService;
import com.influencer.epam_spring_tasks.util.ValidationUtils;
import java.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TrainingServiceImpl implements TrainingService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrainingServiceImpl.class);

    private final TrainingRepository trainingRepository;
    private final TraineeRepository traineeRepository;
    private final TrainerRepository trainerRepository;
    private final TrainingTypeRepository trainingTypeRepository;
    private final ResponseMapper mapper;
    private final TrainerWorkloadClient trainerWorkloadClient;

    public TrainingServiceImpl(
            TrainingRepository trainingRepository,
            TraineeRepository traineeRepository,
            TrainerRepository trainerRepository,
            TrainingTypeRepository trainingTypeRepository,
            ResponseMapper mapper,
            TrainerWorkloadClient trainerWorkloadClient
    ) {
        this.trainingRepository = trainingRepository;
        this.traineeRepository = traineeRepository;
        this.trainerRepository = trainerRepository;
        this.trainingTypeRepository = trainingTypeRepository;
        this.mapper = mapper;
        this.trainerWorkloadClient = trainerWorkloadClient;
    }

    @Override
    @Transactional
    public TrainingResponse addTraining(TrainingAddRequest request) {
        String transactionId = MDC.get("transactionId");
        LOGGER.info("[{}] Adding training name='{}' trainee='{}' trainer='{}'",
                transactionId, request.getTrainingName(),
                request.getTraineeUsername(),
                request.getTrainerUsername());

        validateAddTrainingRequest(request);

        Trainee trainee = traineeRepository.findByUserUsername(request.getTraineeUsername())
                .orElseThrow(() -> {
                    LOGGER.warn("[{}] Trainee not found username='{}'", transactionId, request.getTraineeUsername());
                    return new ValidationException("Trainee not found by username: " + request.getTraineeUsername());
                });

        Trainer trainer = trainerRepository.findByUsername(request.getTrainerUsername())
                .orElseThrow(() -> {
                    LOGGER.warn("[{}] Trainer not found username='{}'", transactionId, request.getTrainerUsername());
                    return new ValidationException("Trainer not found by username: " + request.getTrainerUsername());
                });

        TrainingType trainingType = resolveTrainingType(request);

        Training training = new Training();
        training.setTrainee(trainee);
        training.setTrainer(trainer);
        training.setTrainingName(request.getTrainingName().trim());
        training.setTrainingType(trainingType);
        training.setTrainingDate(resolveTrainingDate(request));
        training.setTrainingDuration(request.getTrainingDuration());

        Training saved = trainingRepository.save(training);

        // Call microservice to record trainer workload
        callTrainerWorkloadService(trainer, saved, "ADD", transactionId);

        LOGGER.info("[{}] Training created id={} name='{}'", transactionId, saved.getId(), saved.getTrainingName());
        return mapper.toTrainingResponse(saved);
    }

    private void callTrainerWorkloadService(Trainer trainer, Training training, String action, String transactionId) {
        try {
            TrainerWorkloadRequest workloadRequest = new TrainerWorkloadRequest()
                    .setTrainerUsername(trainer.getUser().getUsername())
                    .setTrainerFirstName(trainer.getUser().getFirstName())
                    .setTrainerLastName(trainer.getUser().getLastName())
                    .setIsActive(trainer.getUser().isActive())
                    .setTrainingDate(training.getTrainingDate())
                    .setTrainingDuration(training.getTrainingDuration())
                    .setActionType(action);

            LOGGER.debug("[{}] Calling trainer-workload-service with action={}", transactionId, action);
            trainerWorkloadClient.processTrainerWorkload(workloadRequest);
            LOGGER.debug("[{}] Trainer workload service processed successfully", transactionId);
        } catch (Exception ex) {
            LOGGER.warn("[{}] Failed to call trainer workload service: {}", transactionId, ex.getMessage());
            // Don't fail the training creation if microservice is unavailable (circuit breaker fallback)
        }
    }

    private void validateAddTrainingRequest(TrainingAddRequest request) {
        if (request == null) {
            throw new ValidationException("Training request must not be null");
        }

        ValidationUtils.requireNotBlank(request.getTrainingName(), "trainingName");
        ValidationUtils.requireNotBlank(request.getTraineeUsername(), "traineeUsername");
        ValidationUtils.requireNotBlank(request.getTrainerUsername(), "trainerUsername");

        if (request.getTrainingDuration() == null || request.getTrainingDuration() <= 0) {
            throw new ValidationException("trainingDuration must be greater than zero");
        }
    }

    private TrainingType resolveTrainingType(TrainingAddRequest request) {
        if (request.getTrainingTypeName() != null && !request.getTrainingTypeName().trim().isEmpty()) {
            return trainingTypeRepository.findByTrainingTypeName(request.getTrainingTypeName().trim())
                    .orElseThrow(() -> {
                        LOGGER.warn("Training type not found type='{}'", request.getTrainingTypeName());
                        return new ValidationException("Training type not found: " + request.getTrainingTypeName());
                    });
        }

        // Fallback: use trainer specialization if request type is not supplied.
        if (request.getTrainerUsername() != null) {
            Trainer trainer = trainerRepository.findByUsername(request.getTrainerUsername())
                    .orElseThrow(() -> new ValidationException("Trainer not found by username: " + request.getTrainerUsername()));
            if (trainer.getSpecialization() != null) {
                return trainer.getSpecialization();
            }
        }

        throw new ValidationException("Training type is required");
    }

    private LocalDate resolveTrainingDate(TrainingAddRequest request) {
        if (request.getTrainingDate() != null) {
            return request.getTrainingDate();
        }
        return LocalDate.now();
    }
}