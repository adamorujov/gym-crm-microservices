package com.influencer.epam_spring_tasks.repository;

import com.influencer.epam_spring_tasks.model.Training;
import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainingRepository extends JpaRepository<Training, Long> {

    @Query("""
            select t
            from Training t
            where t.trainee.user.username = :traineeUsername
              and (:fromDate is null or t.trainingDate >= :fromDate)
              and (:toDate is null or t.trainingDate <= :toDate)
              and (:trainerName is null or lower(concat(t.trainer.user.firstName, ' ', t.trainer.user.lastName)) like lower(concat('%', :trainerName, '%')))
              and (:trainingTypeName is null or t.trainingType.trainingTypeName = :trainingTypeName)
            order by t.trainingDate desc
            """)
    List<Training> findTraineeTrainings(
            @Param("traineeUsername") String traineeUsername,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            @Param("trainerName") String trainerName,
            @Param("trainingTypeName") String trainingTypeName
    );

    @Query("""
            select t
            from Training t
            where t.trainer.user.username = :trainerUsername
              and (:fromDate is null or t.trainingDate >= :fromDate)
              and (:toDate is null or t.trainingDate <= :toDate)
              and (:traineeName is null or lower(concat(t.trainee.user.firstName, ' ', t.trainee.user.lastName)) like lower(concat('%', :traineeName, '%')))
            order by t.trainingDate desc
            """)
    List<Training> findTrainerTrainings(
            @Param("trainerUsername") String trainerUsername,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            @Param("traineeName") String traineeName
    );
}