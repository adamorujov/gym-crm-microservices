package com.influencer.epam_spring_tasks.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class RequestResponseLoggingInterceptor implements HandlerInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(RequestResponseLoggingInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String transactionId = MDC.get("transactionId");
        long startTime = System.currentTimeMillis();
        request.setAttribute("startTime", startTime);

        logger.info("Transaction [{}] - {} {} from {}",
                transactionId,
                request.getMethod(),
                request.getRequestURI(),
                request.getRemoteAddr());

        logger.debug("Transaction [{}] - Request headers: Content-Type={}, authUsername={}",
                transactionId,
                request.getContentType(),
                request.getHeader("authUsername"));

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) throws Exception {
        Long startTime = (Long) request.getAttribute("startTime");
        long duration = System.currentTimeMillis() - startTime;
        String transactionId = MDC.get("transactionId");

        logger.info("Transaction [{}] - {} {} completed with status {} in {}ms",
                transactionId,
                request.getMethod(),
                request.getRequestURI(),
                response.getStatus(),
                duration);

        if (ex != null) {
            logger.error("Transaction [{}] - Exception occurred: {}", transactionId, ex.getMessage(), ex);
        }
    }
}