package com.influencer.epam_spring_tasks.dto.request;

import java.time.LocalDate;

public class TraineeTrainingsFilterRequest {
    private String username;
    private LocalDate periodFrom;
    private LocalDate periodTo;
    private String trainerName;
    private String trainingType;

    public String getUsername() {
        return username;
    }

    public TraineeTrainingsFilterRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public LocalDate getPeriodFrom() {
        return periodFrom;
    }

    public TraineeTrainingsFilterRequest setPeriodFrom(LocalDate periodFrom) {
        this.periodFrom = periodFrom;
        return this;
    }

    public LocalDate getPeriodTo() {
        return periodTo;
    }

    public TraineeTrainingsFilterRequest setPeriodTo(LocalDate periodTo) {
        this.periodTo = periodTo;
        return this;
    }

    public String getTrainerName() {
        return trainerName;
    }

    public TraineeTrainingsFilterRequest setTrainerName(String trainerName) {
        this.trainerName = trainerName;
        return this;
    }

    public String getTrainingType() {
        return trainingType;
    }

    public TraineeTrainingsFilterRequest setTrainingType(String trainingType) {
        this.trainingType = trainingType;
        return this;
    }
}
