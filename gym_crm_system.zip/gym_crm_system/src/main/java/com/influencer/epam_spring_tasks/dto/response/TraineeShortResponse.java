
package com.influencer.epam_spring_tasks.dto.response;

import java.time.LocalDate;

public class TraineeShortResponse {
    private String traineeUsername;
    private String traineeFirstName;
    private String traineeLastName;

    public String getTraineeUsername() {
        return traineeUsername;
    }

    public TraineeShortResponse setTraineeUsername(String traineeUsername) {
        this.traineeUsername = traineeUsername;
        return this;
    }

    public String getTraineeFirstName() {
        return traineeFirstName;
    }

    public TraineeShortResponse setTraineeFirstName(String traineeFirstName) {
        this.traineeFirstName = traineeFirstName;
        return this;
    }

    public String getTraineeLastName() {
        return traineeLastName;
    }

    public TraineeShortResponse setTraineeLastName(String traineeLastName) {
        this.traineeLastName = traineeLastName;
        return this;
    }
}