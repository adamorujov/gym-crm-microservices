package com.influencer.epam_spring_tasks.repository;

import com.influencer.epam_spring_tasks.model.Trainer;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TrainerRepository extends JpaRepository<Trainer, Long> {

    @Query("select t from Trainer t where t.user.username = :username")
    Optional<Trainer> findByUsername(@Param("username") String username);

    @Query("select t from Trainer t where t.user.username in :usernames")
    List<Trainer> findByUsernameIn(@Param("usernames") Collection<String> usernames);

    @Query("""
           select t
           from Trainer t
           where t.user.active = true
             and t.user.username not in (
                select tr.user.username
                from Trainee trn
                join trn.trainers tr
                where trn.user.username = :traineeUsername
             )
           """)
    List<Trainer> findUnassignedByTraineeUsername(@Param("traineeUsername") String traineeUsername);
}