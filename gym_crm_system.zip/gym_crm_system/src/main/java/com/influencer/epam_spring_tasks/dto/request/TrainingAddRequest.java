package com.influencer.epam_spring_tasks.dto.request;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public class TrainingAddRequest {
    @NotBlank(message = "Trainee username must not be blank")
    private String traineeUsername;
    @NotBlank(message = "Trainer username must not be blank")
    private String trainerUsername;
    @NotBlank(message = "Training name must not be blank")
    private String trainingName;
    @NotBlank(message = "Training type name must not be blank")
    private String trainingTypeName;
    @NotNull(message = "Training date is required")
    private LocalDate trainingDate;
    @Min(value = 1, message = "Training duration must be at least 1 hour")
    private Integer trainingDuration;

    public String getTraineeUsername() {
        return traineeUsername;
    }

    public TrainingAddRequest setTraineeUsername(String traineeUsername) {
        this.traineeUsername = traineeUsername;
        return this;
    }

    public String getTrainerUsername() {
        return trainerUsername;
    }

    public TrainingAddRequest setTrainerUsername(String trainerUsername) {
        this.trainerUsername = trainerUsername;
        return this;
    }

    public String getTrainingName() {
        return trainingName;
    }

    public TrainingAddRequest setTrainingName(String trainingName) {
        this.trainingName = trainingName;
        return this;
    }

    public LocalDate getTrainingDate() {
        return trainingDate;
    }

    public TrainingAddRequest setTrainingDate(LocalDate trainingDate) {
        this.trainingDate = trainingDate;
        return this;
    }

    public Integer getTrainingDuration() {
        return trainingDuration;
    }

    public TrainingAddRequest setTrainingDuration(Integer trainingDuration) {
        this.trainingDuration = trainingDuration;
        return this;
    }

    public String getTrainingTypeName() {
        return trainingTypeName;
    }

    public TrainingAddRequest setTrainingTypeName(String trainingTypeName) {
        this.trainingTypeName = trainingTypeName;
        return this;
    }
}
