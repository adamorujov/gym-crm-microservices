package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.model.LoginAttempt;
import com.influencer.epam_spring_tasks.repository.LoginAttemptRepository;
import com.influencer.epam_spring_tasks.service.BruteForceProtectionService;
import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BruteForceProtectionServiceImpl implements BruteForceProtectionService {

    private final LoginAttemptRepository loginAttemptRepository;
    private final int maxAttempts;
    private final int blockMinutes;

    public BruteForceProtectionServiceImpl(
            LoginAttemptRepository loginAttemptRepository,
            @Value("${security.brute-force.max-attempts:3}") int maxAttempts,
            @Value("${security.brute-force.block-minutes:5}") int blockMinutes
    ) {
        this.loginAttemptRepository = loginAttemptRepository;
        this.maxAttempts = maxAttempts;
        this.blockMinutes = blockMinutes;
    }

    @Override
    @Transactional
    public void onFailedLogin(String username) {
        LoginAttempt attempt = loginAttemptRepository.findByUsername(username)
                .orElseGet(() -> new LoginAttempt().setUsername(username).setFailedAttempts(0));

        attempt.setFailedAttempts(attempt.getFailedAttempts() + 1);

        if (attempt.getFailedAttempts() >= maxAttempts) {
            attempt.setBlockedUntil(LocalDateTime.now().plusMinutes(blockMinutes));
            attempt.setFailedAttempts(0);
        }

        loginAttemptRepository.save(attempt);
    }

    @Override
    @Transactional
    public void onSuccessfulLogin(String username) {
        loginAttemptRepository.findByUsername(username)
                .ifPresent(loginAttemptRepository::delete);
    }

    @Override
    @Transactional(readOnly = true)
    public void checkBlocked(String username) {
        LoginAttempt attempt = loginAttemptRepository.findByUsername(username).orElse(null);
        if (attempt == null || attempt.getBlockedUntil() == null) {
            return;
        }

        if (attempt.getBlockedUntil().isAfter(LocalDateTime.now())) {
            throw new AuthenticationException("User is blocked until " + attempt.getBlockedUntil());
        }

        loginAttemptRepository.delete(attempt);
    }
}