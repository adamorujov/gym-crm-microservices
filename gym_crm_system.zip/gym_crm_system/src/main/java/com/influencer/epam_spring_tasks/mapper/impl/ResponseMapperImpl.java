package com.influencer.epam_spring_tasks.mapper.impl;

import com.influencer.epam_spring_tasks.dto.response.TraineeResponse;
import com.influencer.epam_spring_tasks.dto.response.TraineeShortResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerShortResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.mapper.ResponseMapper;
import com.influencer.epam_spring_tasks.model.Trainee;
import com.influencer.epam_spring_tasks.model.Trainer;
import com.influencer.epam_spring_tasks.model.Training;
import java.util.List;
import java.util.Objects;
import org.springframework.stereotype.Component;

@Component
public class ResponseMapperImpl implements ResponseMapper {

    @Override
    public TraineeResponse toTraineeResponse(Trainee entity) {
        if (entity == null || entity.getUser() == null) {
            return null;
        }

        TraineeResponse response = new TraineeResponse();
        response.setFirstName(entity.getUser().getFirstName());
        response.setLastName(entity.getUser().getLastName());
        response.setUsername(entity.getUser().getUsername());
        response.setIsActive(entity.getUser().isActive());
        response.setDateOfBirth(entity.getDateOfBirth());
        response.setAddress(entity.getAddress());

        List<TrainerShortResponse> trainers = entity.getTrainers().stream()
                .map(this::toTrainerShortResponse)
                .filter(Objects::nonNull)
                .toList();
        response.setTrainers(trainers);

        return response;
    }

    @Override
    public TrainerResponse toTrainerResponse(Trainer entity) {
        if (entity == null || entity.getUser() == null) {
            return null;
        }

        TrainerResponse response = new TrainerResponse();
        response.setFirstName(entity.getUser().getFirstName());
        response.setLastName(entity.getUser().getLastName());
        response.setUsername(entity.getUser().getUsername());
        response.setIsActive(entity.getUser().isActive());
        response.setSpecialization(
                entity.getSpecialization() != null ? entity.getSpecialization().getTrainingTypeName() : null
        );

        List<TraineeShortResponse> trainees = entity.getTrainees().stream()
                .map(this::toTraineeShortResponse)
                .filter(Objects::nonNull)
                .toList();
        response.setTrainees(trainees);

        return response;
    }

    @Override
    public TrainingResponse toTrainingResponse(Training entity) {
        if (entity == null) {
            return null;
        }

        TrainingResponse response = new TrainingResponse();
        response.setTrainingName(entity.getTrainingName());
        response.setTrainingType(
                entity.getTrainingType() != null ? entity.getTrainingType().getTrainingTypeName() : null
        );
        response.setTrainingDate(entity.getTrainingDate());
        response.setTrainingDuration(entity.getTrainingDuration());

        if (entity.getTrainer() != null && entity.getTrainer().getUser() != null) {
            response.setTrainerName(
                    entity.getTrainer().getUser().getFirstName() + " " +
                            entity.getTrainer().getUser().getLastName()
            );
        }

        if (entity.getTrainee() != null && entity.getTrainee().getUser() != null) {
            response.setTraineeName(
                    entity.getTrainee().getUser().getFirstName() + " " +
                            entity.getTrainee().getUser().getLastName()
            );
        }

        return response;
    }

    @Override
    public TrainerShortResponse toTrainerShortResponse(Trainer entity) {
        if (entity == null || entity.getUser() == null) {
            return null;
        }

        TrainerShortResponse response = new TrainerShortResponse();
        response.setTrainerUsername(entity.getUser().getUsername());
        response.setTrainerFirstName(entity.getUser().getFirstName());
        response.setTrainerLastName(entity.getUser().getLastName());
        response.setTrainerSpecialization(
                entity.getSpecialization() != null ? entity.getSpecialization().getTrainingTypeName() : null
        );
        return response;
    }

    @Override
    public TraineeShortResponse toTraineeShortResponse(Trainee entity) {
        if (entity == null || entity.getUser() == null) {
            return null;
        }

        TraineeShortResponse response = new TraineeShortResponse();
        response.setTraineeUsername(entity.getUser().getUsername());
        response.setTraineeFirstName(entity.getUser().getFirstName());
        response.setTraineeLastName(entity.getUser().getLastName());
        return response;
    }

    @Override
    public List<TrainingResponse> toTrainingResponses(List<Training> entities) {
        return entities.stream().map(this::toTrainingResponse).toList();
    }

    @Override
    public List<TrainerShortResponse> toTrainerShortResponses(List<Trainer> entities) {
        return entities.stream().map(this::toTrainerShortResponse).toList();
    }
}