package com.influencer.epam_spring_tasks.dto.response;

public class TrainingTypeResponse {
    private Long trainingTypeId;
    private String trainingType;

    public Long getTrainingTypeId() {
        return trainingTypeId;
    }

    public TrainingTypeResponse setTrainingTypeId(Long trainingTypeId) {
        this.trainingTypeId = trainingTypeId;
        return this;
    }

    public String getTrainingType() {
        return trainingType;
    }

    public TrainingTypeResponse setTrainingType(String trainingType) {
        this.trainingType = trainingType;
        return this;
    }
}
