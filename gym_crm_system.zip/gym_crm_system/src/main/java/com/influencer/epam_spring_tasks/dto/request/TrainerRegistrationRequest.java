package com.influencer.epam_spring_tasks.dto.request;

import jakarta.validation.constraints.NotBlank;

public class TrainerRegistrationRequest {
    @NotBlank(message = "First name must not be blank")
    private String firstName;
    @NotBlank(message = "Last name must not be blank")
    private String lastName;
    @NotBlank(message = "Specialization must not be blank")
    private String specialization;

    public String getFirstName() {
        return firstName;
    }

    public TrainerRegistrationRequest setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public TrainerRegistrationRequest setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getSpecialization() {
        return specialization;
    }

    public TrainerRegistrationRequest setSpecialization(String specialization) {
        this.specialization = specialization;
        return this;
    }
}
