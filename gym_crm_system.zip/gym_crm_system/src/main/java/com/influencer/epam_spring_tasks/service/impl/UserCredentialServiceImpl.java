package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.repository.UserRepository;
import com.influencer.epam_spring_tasks.service.UserCredentialService;
import com.influencer.epam_spring_tasks.util.PasswordGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserCredentialServiceImpl implements UserCredentialService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserCredentialServiceImpl.class);

    private final UserRepository userRepository;

    public UserCredentialServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public String generateUsername(String firstName, String lastName) {
        LOGGER.info("Generating username for firstName='{}', lastName='{}'", firstName, lastName);

        String normalizedFirst = normalize(firstName);
        String normalizedLast = normalize(lastName);

        String baseUsername = normalizedFirst + "." + normalizedLast;
        String candidate = baseUsername;
        int suffix = 1;

        while (userRepository.findByUsername(candidate).isPresent()) {
            candidate = baseUsername + suffix;
            suffix++;
        }

        LOGGER.debug("Generated unique username='{}' from base='{}'", candidate, baseUsername);
        return candidate;
    }

    @Override
    @Transactional(readOnly = true)
    public String generatePassword() {
        LOGGER.info("Generating random password");
        String generatedPassword = PasswordGenerator.generate(10);
        LOGGER.debug("Generated password with length={}", generatedPassword.length());
        return generatedPassword;
    }

    private String normalize(String value) {
        if (value == null) {
            return "";
        }
        return value.trim().replaceAll("\\s+", "").toLowerCase();
    }
}