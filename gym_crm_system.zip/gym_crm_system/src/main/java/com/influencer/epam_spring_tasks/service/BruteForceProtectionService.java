package com.influencer.epam_spring_tasks.service;

public interface BruteForceProtectionService {
    void onFailedLogin(String username);
    void onSuccessfulLogin(String username);
    void checkBlocked(String username);
}