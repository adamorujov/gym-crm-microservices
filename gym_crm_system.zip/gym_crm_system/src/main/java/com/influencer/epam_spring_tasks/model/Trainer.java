package com.influencer.epam_spring_tasks.model;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "trainers")
public class Trainer{

    @Id
    @Column(name = "user_id")
    private Long userId;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @MapsId
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "specialization_id", nullable = false)
    private TrainingType specialization;

    @ManyToMany(mappedBy = "trainers")
    private Set<Trainee> trainees = new HashSet<>();

    @OneToMany(mappedBy = "trainer", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Training> trainings = new HashSet<>();

    public Long getUserId() {
        return userId;
    }

    public User getUser() {
        return user;
    }

    public Trainer setUser(User user) {
        this.user = user;
        return this;
    }

    public TrainingType getSpecialization() {
        return specialization;
    }

    public Trainer setSpecialization(TrainingType specialization) {
        this.specialization = specialization;
        return this;
    }

    public Set<Trainee> getTrainees() {
        return trainees;
    }

    public Trainer setTrainees(Set<Trainee> trainees) {
        this.trainees = trainees;
        return this;
    }

    public Set<Training> getTrainings() {
        return trainings;
    }

    public Trainer setTrainings(Set<Training> trainings) {
        this.trainings = trainings;
        return this;
    }
}
