package com.influencer.epam_spring_tasks.repository;

import com.influencer.epam_spring_tasks.model.Trainee;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TraineeRepository extends JpaRepository<Trainee, Long> {

    Optional<Trainee> findByUserUsername(String username);

    boolean existsByUserUsername(String username);
}