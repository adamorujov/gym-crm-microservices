
package com.influencer.epam_spring_tasks.dto.response;

public class TrainerShortResponse {
    private String trainerUsername;
    private String trainerFirstName;
    private String trainerLastName;
    private String trainerSpecialization;

    public String getTrainerUsername() {
        return trainerUsername;
    }

    public TrainerShortResponse setTrainerUsername(String trainerUsername) {
        this.trainerUsername = trainerUsername;
        return this;
    }

    public String getTrainerFirstName() {
        return trainerFirstName;
    }

    public TrainerShortResponse setTrainerFirstName(String trainerFirstName) {
        this.trainerFirstName = trainerFirstName;
        return this;
    }

    public String getTrainerLastName() {
        return trainerLastName;
    }

    public TrainerShortResponse setTrainerLastName(String trainerLastName) {
        this.trainerLastName = trainerLastName;
        return this;
    }

    public String getTrainerSpecialization() {
        return trainerSpecialization;
    }

    public TrainerShortResponse setTrainerSpecialization(String trainerSpecialization) {
        this.trainerSpecialization = trainerSpecialization;
        return this;
    }
}