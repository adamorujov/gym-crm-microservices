package com.influencer.epam_spring_tasks.monitoring.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Component;

@Component
public class GymMetricsService {

    private final Counter traineeRegistrationsCounter;
    private final Counter trainerRegistrationsCounter;
    private final Counter successfulLoginsCounter;
    private final Counter failedLoginsCounter;
    private final Counter trainingsCreatedCounter;
    private final Counter traineeTrainerUpdatesCounter;
    private final Timer authenticationTimer;

    public GymMetricsService(MeterRegistry meterRegistry) {
        this.traineeRegistrationsCounter = Counter.builder("gym.trainee.registrations")
                .description("Number of trainee registrations")
                .register(meterRegistry);

        this.trainerRegistrationsCounter = Counter.builder("gym.trainer.registrations")
                .description("Number of trainer registrations")
                .register(meterRegistry);

        this.successfulLoginsCounter = Counter.builder("gym.auth.login.success")
                .description("Number of successful login attempts")
                .register(meterRegistry);

        this.failedLoginsCounter = Counter.builder("gym.auth.login.failure")
                .description("Number of failed login attempts")
                .register(meterRegistry);

        this.trainingsCreatedCounter = Counter.builder("gym.training.created")
                .description("Number of created trainings")
                .register(meterRegistry);

        this.traineeTrainerUpdatesCounter = Counter.builder("gym.trainee.trainer.update")
                .description("Number of trainee trainer list updates")
                .register(meterRegistry);

        this.authenticationTimer = Timer.builder("gym.auth.duration")
                .description("Authentication processing duration")
                .publishPercentileHistogram()
                .register(meterRegistry);
    }

    public void incrementTraineeRegistrations() {
        traineeRegistrationsCounter.increment();
    }

    public void incrementTrainerRegistrations() {
        trainerRegistrationsCounter.increment();
    }

    public void incrementSuccessfulLogins() {
        successfulLoginsCounter.increment();
    }

    public void incrementFailedLogins() {
        failedLoginsCounter.increment();
    }

    public void incrementTrainingsCreated() {
        trainingsCreatedCounter.increment();
    }

    public void incrementTraineeTrainerUpdates() {
        traineeTrainerUpdatesCounter.increment();
    }

    public void recordAuthenticationDuration(long durationNanos) {
        authenticationTimer.record(durationNanos, TimeUnit.NANOSECONDS);
    }
}