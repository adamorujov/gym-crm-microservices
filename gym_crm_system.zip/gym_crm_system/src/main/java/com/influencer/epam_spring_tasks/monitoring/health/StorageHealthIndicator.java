package com.influencer.epam_spring_tasks.monitoring.health;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import java.io.File;

@Component("storageHealth")
public class StorageHealthIndicator implements HealthIndicator {

    private final String storagePath;

    public StorageHealthIndicator(
            @Value("${app.storage.path:./data}") String storagePath) {
        this.storagePath = storagePath;
    }

    @Override
    public Health health() {
        File path = new File(storagePath);
        if (!path.exists()) {
            return Health.down()
                    .withDetail("storagePath", storagePath)
                    .withDetail("reason", "path does not exist")
                    .build();
        }

        long usable = path.getUsableSpace();
        long total = path.getTotalSpace();

        if (!path.canRead() || !path.canWrite()) {
            return Health.down()
                    .withDetail("storagePath", storagePath)
                    .withDetail("readable", path.canRead())
                    .withDetail("writable", path.canWrite())
                    .build();
        }

        return Health.up()
                .withDetail("storagePath", storagePath)
                .withDetail("usableBytes", usable)
                .withDetail("totalBytes", total)
                .build();
    }
}
