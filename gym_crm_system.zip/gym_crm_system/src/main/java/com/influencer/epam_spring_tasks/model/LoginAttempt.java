package com.influencer.epam_spring_tasks.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "login_attempts")
public class LoginAttempt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "username", nullable = false, unique = true)
    private String username;

    @Column(name = "failed_attempts", nullable = false)
    private int failedAttempts;

    @Column(name = "blocked_until")
    private LocalDateTime blockedUntil;

    public Long getId() {
        return id;
    }

    public LoginAttempt setId(Long id) {
        this.id = id;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public LoginAttempt setUsername(String username) {
        this.username = username;
        return this;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public LoginAttempt setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
        return this;
    }

    public LocalDateTime getBlockedUntil() {
        return blockedUntil;
    }

    public LoginAttempt setBlockedUntil(LocalDateTime blockedUntil) {
        this.blockedUntil = blockedUntil;
        return this;
    }
}