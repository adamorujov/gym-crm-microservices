package com.influencer.epam_spring_tasks.dto.request;

import jakarta.validation.constraints.NotBlank;

import java.time.LocalDate;

public class TraineeProfileUpdateRequest {
    @NotBlank(message = "Username must not be blank")
    private String username;
    @NotBlank(message = "First name must not be blank")
    private String firstName;
    @NotBlank(message = "Last name must not be blank")
    private String lastName;
    private LocalDate dateOfBirth;
    @NotBlank(message = "Address must not be blank")
    private String address;
    private Boolean isActive;

    public String getUsername() {
        return username;
    }

    public TraineeProfileUpdateRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getFirstName() {
        return firstName;
    }

    public TraineeProfileUpdateRequest setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public TraineeProfileUpdateRequest setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public TraineeProfileUpdateRequest setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public TraineeProfileUpdateRequest setAddress(String address) {
        this.address = address;
        return this;
    }

    public Boolean getActive() {
        return isActive;
    }

    public TraineeProfileUpdateRequest setActive(Boolean active) {
        isActive = active;
        return this;
    }
}
