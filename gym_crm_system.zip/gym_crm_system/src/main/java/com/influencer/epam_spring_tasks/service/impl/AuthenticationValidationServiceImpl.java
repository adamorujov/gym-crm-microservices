package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.service.AuthenticationService;
import com.influencer.epam_spring_tasks.service.AuthenticationValidationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationValidationServiceImpl implements AuthenticationValidationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationValidationServiceImpl.class);

    private final AuthenticationService authenticationService;

    public AuthenticationValidationServiceImpl(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @Override
    public void validateCredentials(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            LOGGER.warn("Authentication attempt with empty username");
            throw new AuthenticationException("Username is required");
        }

        if (password == null || password.trim().isEmpty()) {
            LOGGER.warn("Authentication attempt with empty password for username: {}", username);
            throw new AuthenticationException("Password is required");
        }

        boolean isValid = authenticationService.authenticate(username, password);
        if (!isValid) {
            LOGGER.warn("Authentication failed for username: {}", username);
            throw new AuthenticationException("Invalid username or password");
        }

        LOGGER.debug("Authentication successful for username: {}", username);
    }
}
