package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.dto.request.CreateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.request.TrainerTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.UpdateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.mapper.ResponseMapper;
import com.influencer.epam_spring_tasks.model.Trainer;
import com.influencer.epam_spring_tasks.model.Training;
import com.influencer.epam_spring_tasks.model.TrainingType;
import com.influencer.epam_spring_tasks.model.User;
import com.influencer.epam_spring_tasks.repository.TrainerRepository;
import com.influencer.epam_spring_tasks.repository.TrainingRepository;
import com.influencer.epam_spring_tasks.repository.TrainingTypeRepository;
import com.influencer.epam_spring_tasks.repository.UserRepository;
import com.influencer.epam_spring_tasks.service.TrainerService;
import com.influencer.epam_spring_tasks.service.UserCredentialService;
import com.influencer.epam_spring_tasks.util.ValidationUtils;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TrainerServiceImpl implements TrainerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrainerServiceImpl.class);

    private final TrainerRepository trainerRepository;
    private final TrainingTypeRepository trainingTypeRepository;
    private final TrainingRepository trainingRepository;
    private final UserRepository userRepository;
    private final UserCredentialService credentialService;
    private final ResponseMapper mapper;
    private final PasswordEncoder passwordEncoder;

    public TrainerServiceImpl(
            TrainerRepository trainerRepository,
            TrainingTypeRepository trainingTypeRepository,
            TrainingRepository trainingRepository,
            UserRepository userRepository,
            UserCredentialService credentialService,
            ResponseMapper mapper,
            PasswordEncoder passwordEncoder
    ) {
        this.trainerRepository = trainerRepository;
        this.trainingTypeRepository = trainingTypeRepository;
        this.trainingRepository = trainingRepository;
        this.userRepository = userRepository;
        this.credentialService = credentialService;
        this.mapper = mapper;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public CredentialResponse createTrainer(CreateTrainerRequest request) {
        LOGGER.info("Creating trainer firstName='{}' lastName='{}' specialization='{}'",
                request.getFirstName(), request.getLastName(), request.getSpecializationTypeName());

        ValidationUtils.requireNotBlank(request.getFirstName(), "firstName");
        ValidationUtils.requireNotBlank(request.getLastName(), "lastName");
        ValidationUtils.requireNotBlank(request.getSpecializationTypeName(), "specializationTypeName");

        TrainingType specialization = trainingTypeRepository.findByTrainingTypeName(request.getSpecializationTypeName())
                .orElseThrow(() -> {
                    LOGGER.warn("Training type not found specialization='{}'", request.getSpecializationTypeName());
                    return new ValidationException("Training type not found: " + request.getSpecializationTypeName());
                });

        String rawPassword = credentialService.generatePassword();

        User user = new User();
        user.setFirstName(request.getFirstName().trim());
        user.setLastName(request.getLastName().trim());
        user.setUsername(credentialService.generateUsername(request.getFirstName(), request.getLastName()));
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setActive(true);
        userRepository.save(user);

        Trainer trainer = new Trainer();
        trainer.setUser(user);
        trainer.setSpecialization(specialization);
        trainerRepository.save(trainer);

        LOGGER.info("Created trainer username='{}' userId={}", user.getUsername(), user.getUserId());
        return new CredentialResponse(user.getUsername(), rawPassword);
    }

    @Override
    @Transactional(readOnly = true)
    public TrainerResponse getTrainerByUsername(String username) {
        LOGGER.info("Fetching trainer profile username='{}'", username);

        Trainer trainer = trainerRepository.findByUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainer not found username='{}'", username);
                    return new ValidationException("Trainer not found by username: " + username);
                });

        return mapper.toTrainerResponse(trainer);
    }

    @Override
    @Transactional
    public TrainerResponse updateTrainer(UpdateTrainerRequest request) {
        LOGGER.info("Updating trainer targetUsername='{}'", request.getTargetUsername());

        Trainer trainer = trainerRepository.findByUsername(request.getTargetUsername())
                .orElseThrow(() -> {
                    LOGGER.warn("Trainer not found for update username='{}'", request.getTargetUsername());
                    return new ValidationException("Trainer not found by username: " + request.getTargetUsername());
                });

        User user = trainer.getUser();

        if (request.getFirstName() != null) {
            ValidationUtils.requireNotBlank(request.getFirstName(), "firstName");
            user.setFirstName(request.getFirstName().trim());
        }
        if (request.getLastName() != null) {
            ValidationUtils.requireNotBlank(request.getLastName(), "lastName");
            user.setLastName(request.getLastName().trim());
        }
        if (request.getSpecializationTypeName() != null) {
            TrainingType specialization = trainingTypeRepository.findByTrainingTypeName(request.getSpecializationTypeName())
                    .orElseThrow(() -> {
                        LOGGER.warn("Training type not found for update specialization='{}'",
                                request.getSpecializationTypeName());
                        return new ValidationException("Training type not found: " + request.getSpecializationTypeName());
                    });
            trainer.setSpecialization(specialization);
        }
        if (request.getIsActive() != null) {
            user.setActive(request.getIsActive());
        }

        userRepository.save(user);
        Trainer updated = trainerRepository.save(trainer);

        LOGGER.info("Updated trainer username='{}' active={}", updated.getUser().getUsername(), updated.getUser().isActive());
        return mapper.toTrainerResponse(updated);
    }

    @Override
    @Transactional
    public void changeTrainerPassword(String targetUsername, String newPassword) {
        LOGGER.info("Changing trainer password targetUsername='{}'", targetUsername);

        ValidationUtils.requireNotBlank(newPassword, "newPassword");

        Trainer trainer = trainerRepository.findByUsername(targetUsername)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainer not found for password change username='{}'", targetUsername);
                    return new ValidationException("Trainer not found by username: " + targetUsername);
                });

        User user = trainer.getUser();
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        LOGGER.info("Changed trainer password username='{}'", targetUsername);
    }

    @Override
    @Transactional
    public void activateTrainer(String username) {
        LOGGER.info("Activating trainer username='{}'", username);

        Trainer trainer = trainerRepository.findByUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainer not found for activation username='{}'", username);
                    return new ValidationException("Trainer not found by username: " + username);
                });

        User user = trainer.getUser();
        if (Boolean.TRUE.equals(user.isActive())) {
            LOGGER.warn("Trainer already active username='{}'", username);
            throw new ValidationException("Trainer already active: " + username);
        }

        user.setActive(true);
        userRepository.save(user);
        LOGGER.info("Activated trainer username='{}'", username);
    }

    @Override
    @Transactional
    public void deactivateTrainer(String username) {
        LOGGER.info("Deactivating trainer username='{}'", username);

        Trainer trainer = trainerRepository.findByUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainer not found for deactivation username='{}'", username);
                    return new ValidationException("Trainer not found by username: " + username);
                });

        User user = trainer.getUser();
        if (Boolean.FALSE.equals(user.isActive())) {
            LOGGER.warn("Trainer already inactive username='{}'", username);
            throw new ValidationException("Trainer already inactive: " + username);
        }

        user.setActive(false);
        userRepository.save(user);
        LOGGER.info("Deactivated trainer username='{}'", username);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainingResponse> getTrainerTrainings(TrainerTrainingFilter filter) {
        LOGGER.info("Fetching trainer trainings trainerUsername='{}'", filter.getTrainerUsername());

        ValidationUtils.requireNotBlank(filter.getTrainerUsername(), "trainerUsername");

        List<Training> result = trainingRepository.findTrainerTrainings(
                filter.getTrainerUsername(),
                filter.getFromDate(),
                filter.getToDate(),
                filter.getTraineeName()
        );

        LOGGER.debug("Fetched trainer trainings count={} trainerUsername='{}'", result.size(), filter.getTrainerUsername());
        return mapper.toTrainingResponses(result);
    }

    @Override
    public boolean existsByUsername(String username) {
        return trainerRepository.findByUsername(username).isPresent();
    }
}