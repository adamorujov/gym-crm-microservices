package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.dto.request.CreateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.UpdateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TraineeResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerShortResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import java.util.List;

public interface TraineeService {
    CredentialResponse createTrainee(CreateTraineeRequest request);
    TraineeResponse getTraineeByUsername(String username);
    TraineeResponse updateTrainee(UpdateTraineeRequest request);
    void changeTraineePassword(String targetUsername, String newPassword);
    void activateTrainee(String username);
    void deactivateTrainee(String username);
    void deleteTraineeByUsername(String username);
    List<TrainingResponse> getTraineeTrainings(TraineeTrainingFilter filter);
    List<TrainerShortResponse> getUnassignedTrainersByTraineeUsername(String traineeUsername);
    void updateTraineeTrainers(String traineeUsername, List<String> trainerUsernames);

    boolean existsByUsername(String username);
}