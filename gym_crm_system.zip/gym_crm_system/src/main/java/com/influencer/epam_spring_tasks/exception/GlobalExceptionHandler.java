package com.influencer.epam_spring_tasks.exception;

import com.influencer.epam_spring_tasks.dto.response.AuthResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<AuthResponse> handleAuthenticationException(AuthenticationException ex) {
        LOGGER.warn("Authentication error: {}", ex.getMessage());
        return ResponseEntity.status(401)
                .body(new AuthResponse("ERROR", ex.getMessage()));
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<AuthResponse> handleValidationException(ValidationException ex) {
        LOGGER.warn("Validation error: {}", ex.getMessage());
        return ResponseEntity.badRequest()
                .body(new AuthResponse("ERROR", ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<AuthResponse> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        LOGGER.warn("Request validation failed");
        return ResponseEntity.badRequest()
                .body(new AuthResponse("ERROR", "Invalid request"));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<AuthResponse> handleGenericException(Exception ex) {
        LOGGER.error("Unexpected error", ex);
        return ResponseEntity.status(500)
                .body(new AuthResponse("ERROR", "Internal server error"));
    }
}