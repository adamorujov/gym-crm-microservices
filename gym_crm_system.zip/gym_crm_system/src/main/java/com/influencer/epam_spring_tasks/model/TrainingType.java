package com.influencer.epam_spring_tasks.model;

import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "training_types")
public class TrainingType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "training_type_name", nullable = false, unique = true, length = 100)
    private String trainingTypeName;

    @OneToMany(mappedBy = "trainingType")
    private Set<Training> trainings = new HashSet<>();

    public Long getId() {
        return id;
    }

    public String getTrainingTypeName() {
        return trainingTypeName;
    }

    public TrainingType setTrainingTypeName(String trainingTypeName) {
        this.trainingTypeName = trainingTypeName;
        return this;
    }

    public Set<Training> getTrainings() {
        return trainings;
    }

    public TrainingType setTrainings(Set<Training> trainings) {
        this.trainings = trainings;
        return this;
    }
}
