
package com.influencer.epam_spring_tasks.util;

import com.influencer.epam_spring_tasks.exception.ValidationException;

public final class ValidationUtils {

    private ValidationUtils() {
    }

    public static void requireNotBlank(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(fieldName + " must not be blank");
        }
    }
}