package com.influencer.epam_spring_tasks.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ChangePasswordRequest {
    @NotBlank(message = "Username cannot be blank")
    private String username;
    @NotBlank(message = "Old password cannot be blank")
    private String oldPassword;
    @NotBlank(message = "New password cannot be blank")
    @Size(min = 4, message = "New password must be at least 4 characters long")
    private String newPassword;

    public String getUsername() {
        return username;
    }

    public ChangePasswordRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public ChangePasswordRequest setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
        return this;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public ChangePasswordRequest setNewPassword(String newPassword) {
        this.newPassword = newPassword;
        return this;
    }
}
