package com.influencer.epam_spring_tasks.dto.response;

public class LoginResponse {

    private String type;
    private String token;

    public LoginResponse() {
    }

    public LoginResponse(String type, String token) {
        this.type = type;
        this.token = token;
    }

    public String getType() {
        return type;
    }

    public LoginResponse setType(String type) {
        this.type = type;
        return this;
    }

    public String getToken() {
        return token;
    }

    public LoginResponse setToken(String token) {
        this.token = token;
        return this;
    }
}