package com.influencer.epam_spring_tasks.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public class TraineeTrainerListUpdateRequest {

    @NotBlank(message = "Username is required")
    private String username;

    @NotEmpty(message = "Trainer usernames list cannot be empty")
    private List<@NotBlank(message = "Trainer username cannot be blank") String> trainerUsernames;

    public String getUsername() {
        return username;
    }

    public TraineeTrainerListUpdateRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public List<String> getTrainerUsernames() {
        return trainerUsernames;
    }

    public TraineeTrainerListUpdateRequest setTrainerUsernames(List<String> trainerUsernames) {
        this.trainerUsernames = trainerUsernames;
        return this;
    }
}