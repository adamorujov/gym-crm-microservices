package com.influencer.epam_spring_tasks.repository;

import com.influencer.epam_spring_tasks.model.LoginAttempt;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginAttemptRepository extends JpaRepository<LoginAttempt, Long> {
    Optional<LoginAttempt> findByUsername(String username);
    boolean existsByUsername(String username);
}