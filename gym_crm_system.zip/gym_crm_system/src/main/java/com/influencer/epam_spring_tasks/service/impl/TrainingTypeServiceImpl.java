package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.dto.response.TrainingTypeResponse;
import com.influencer.epam_spring_tasks.mapper.ResponseMapper;
import com.influencer.epam_spring_tasks.model.TrainingType;
import com.influencer.epam_spring_tasks.repository.TrainingTypeRepository;
import com.influencer.epam_spring_tasks.service.TrainingTypeService;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TrainingTypeServiceImpl implements TrainingTypeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrainingTypeServiceImpl.class);

    private final TrainingTypeRepository trainingTypeRepository;
    private final ResponseMapper mapper;

    public TrainingTypeServiceImpl(
            TrainingTypeRepository trainingTypeRepository,
            ResponseMapper mapper
    ) {
        this.trainingTypeRepository = trainingTypeRepository;
        this.mapper = mapper;
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainingTypeResponse> getTrainingTypes() {
        LOGGER.info("Fetching all training types");
        List<TrainingType> types = trainingTypeRepository.findAll();
        LOGGER.debug("Fetched training types count={}", types.size());
        return mapper.toTrainingTypeResponses(types);
    }
}