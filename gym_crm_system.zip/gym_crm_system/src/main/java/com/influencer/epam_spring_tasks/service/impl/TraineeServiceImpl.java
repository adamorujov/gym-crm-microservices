package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.dto.request.CreateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.UpdateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TraineeResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerShortResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.mapper.ResponseMapper;
import com.influencer.epam_spring_tasks.model.Trainee;
import com.influencer.epam_spring_tasks.model.Trainer;
import com.influencer.epam_spring_tasks.model.Training;
import com.influencer.epam_spring_tasks.model.User;
import com.influencer.epam_spring_tasks.repository.TraineeRepository;
import com.influencer.epam_spring_tasks.repository.TrainerRepository;
import com.influencer.epam_spring_tasks.repository.TrainingRepository;
import com.influencer.epam_spring_tasks.repository.UserRepository;
import com.influencer.epam_spring_tasks.service.TraineeService;
import com.influencer.epam_spring_tasks.service.UserCredentialService;
import com.influencer.epam_spring_tasks.util.ValidationUtils;
import java.util.HashSet;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TraineeServiceImpl implements TraineeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TraineeServiceImpl.class);

    private final TraineeRepository traineeRepository;
    private final TrainerRepository trainerRepository;
    private final TrainingRepository trainingRepository;
    private final UserRepository userRepository;
    private final UserCredentialService credentialService;
    private final ResponseMapper mapper;
    private final PasswordEncoder passwordEncoder;

    public TraineeServiceImpl(
            TraineeRepository traineeRepository,
            TrainerRepository trainerRepository,
            TrainingRepository trainingRepository,
            UserRepository userRepository,
            UserCredentialService credentialService,
            ResponseMapper mapper,
            PasswordEncoder passwordEncoder
    ) {
        this.traineeRepository = traineeRepository;
        this.trainerRepository = trainerRepository;
        this.trainingRepository = trainingRepository;
        this.userRepository = userRepository;
        this.credentialService = credentialService;
        this.mapper = mapper;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public CredentialResponse createTrainee(CreateTraineeRequest request) {
        LOGGER.info("Creating trainee firstName='{}' lastName='{}'", request.getFirstName(), request.getLastName());

        ValidationUtils.requireNotBlank(request.getFirstName(), "firstName");
        ValidationUtils.requireNotBlank(request.getLastName(), "lastName");

        String rawPassword = credentialService.generatePassword();

        User user = new User();
        user.setFirstName(request.getFirstName().trim());
        user.setLastName(request.getLastName().trim());
        user.setUsername(credentialService.generateUsername(request.getFirstName(), request.getLastName()));
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setActive(true);
        userRepository.save(user);

        Trainee trainee = new Trainee();
        trainee.setUser(user);
        trainee.setDateOfBirth(request.getDateOfBirth());
        trainee.setAddress(request.getAddress());
        traineeRepository.save(trainee);

        LOGGER.info("Created trainee username='{}' userId={}", user.getUsername(), user.getUserId());
        return new CredentialResponse(user.getUsername(), rawPassword);
    }

    @Override
    @Transactional(readOnly = true)
    public TraineeResponse getTraineeByUsername(String username) {
        LOGGER.info("Fetching trainee profile username='{}'", username);

        Trainee trainee = traineeRepository.findByUserUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found username='{}'", username);
                    return new ValidationException("Trainee not found by username: " + username);
                });

        return mapper.toTraineeResponse(trainee);
    }

    @Override
    @Transactional
    public TraineeResponse updateTrainee(UpdateTraineeRequest request) {
        LOGGER.info("Updating trainee targetUsername='{}'", request.getTargetUsername());

        Trainee trainee = traineeRepository.findByUserUsername(request.getTargetUsername())
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found for update username='{}'", request.getTargetUsername());
                    return new ValidationException("Trainee not found by username: " + request.getTargetUsername());
                });

        User user = trainee.getUser();

        if (request.getFirstName() != null) {
            ValidationUtils.requireNotBlank(request.getFirstName(), "firstName");
            user.setFirstName(request.getFirstName().trim());
        }
        if (request.getLastName() != null) {
            ValidationUtils.requireNotBlank(request.getLastName(), "lastName");
            user.setLastName(request.getLastName().trim());
        }
        if (request.getDateOfBirth() != null) {
            trainee.setDateOfBirth(request.getDateOfBirth());
        }
        if (request.getAddress() != null) {
            trainee.setAddress(request.getAddress());
        }
        if (request.getIsActive() != null) {
            user.setActive(request.getIsActive());
        }

        userRepository.save(user);
        Trainee updated = traineeRepository.save(trainee);

        LOGGER.info("Updated trainee username='{}' active={}", updated.getUser().getUsername(), updated.getUser().isActive());
        return mapper.toTraineeResponse(updated);
    }

    @Override
    @Transactional
    public void changeTraineePassword(String targetUsername, String newPassword) {
        LOGGER.info("Changing trainee password targetUsername='{}'", targetUsername);

        ValidationUtils.requireNotBlank(newPassword, "newPassword");

        Trainee trainee = traineeRepository.findByUserUsername(targetUsername)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found for password change username='{}'", targetUsername);
                    return new ValidationException("Trainee not found by username: " + targetUsername);
                });

        User user = trainee.getUser();
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        LOGGER.info("Changed trainee password username='{}'", targetUsername);
    }

    @Override
    @Transactional
    public void activateTrainee(String username) {
        LOGGER.info("Activating trainee username='{}'", username);

        Trainee trainee = traineeRepository.findByUserUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found for activation username='{}'", username);
                    return new ValidationException("Trainee not found by username: " + username);
                });

        User user = trainee.getUser();
        if (Boolean.TRUE.equals(user.isActive())) {
            LOGGER.warn("Trainee already active username='{}'", username);
            throw new ValidationException("Trainee already active: " + username);
        }

        user.setActive(true);
        userRepository.save(user);
        LOGGER.info("Activated trainee username='{}'", username);
    }

    @Override
    @Transactional
    public void deactivateTrainee(String username) {
        LOGGER.info("Deactivating trainee username='{}'", username);

        Trainee trainee = traineeRepository.findByUserUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found for deactivation username='{}'", username);
                    return new ValidationException("Trainee not found by username: " + username);
                });

        User user = trainee.getUser();
        if (Boolean.FALSE.equals(user.isActive())) {
            LOGGER.warn("Trainee already inactive username='{}'", username);
            throw new ValidationException("Trainee already inactive: " + username);
        }

        user.setActive(false);
        userRepository.save(user);
        LOGGER.info("Deactivated trainee username='{}'", username);
    }

    @Override
    @Transactional
    public void deleteTraineeByUsername(String username) {
        LOGGER.info("Deleting trainee username='{}'", username);

        Trainee trainee = traineeRepository.findByUserUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found for deletion username='{}'", username);
                    return new ValidationException("Trainee not found by username: " + username);
                });

        traineeRepository.delete(trainee);
        LOGGER.info("Deleted trainee username='{}'", username);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainingResponse> getTraineeTrainings(TraineeTrainingFilter filter) {
        LOGGER.info("Fetching trainee trainings traineeUsername='{}'", filter.getTraineeUsername());

        ValidationUtils.requireNotBlank(filter.getTraineeUsername(), "traineeUsername");

        List<Training> result = trainingRepository.findTraineeTrainings(
                filter.getTraineeUsername(),
                filter.getFromDate(),
                filter.getToDate(),
                filter.getTrainerName(),
                filter.getTrainingTypeName()
        );

        LOGGER.debug("Fetched trainee trainings count={} traineeUsername='{}'", result.size(), filter.getTraineeUsername());
        return mapper.toTrainingResponses(result);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainerShortResponse> getUnassignedTrainersByTraineeUsername(String traineeUsername) {
        LOGGER.info("Fetching unassigned trainers traineeUsername='{}'", traineeUsername);

        ValidationUtils.requireNotBlank(traineeUsername, "traineeUsername");

        List<Trainer> result = trainerRepository.findUnassignedByTraineeUsername(traineeUsername);
        LOGGER.debug("Fetched unassigned trainers count={} traineeUsername='{}'", result.size(), traineeUsername);

        return mapper.toTrainerShortResponses(result);
    }

    @Override
    @Transactional
    public void updateTraineeTrainers(String traineeUsername, List<String> trainerUsernames) {
        LOGGER.info("Updating trainee trainers traineeUsername='{}' requestedTrainerCount={}",
                traineeUsername, trainerUsernames != null ? trainerUsernames.size() : 0);

        ValidationUtils.requireNotBlank(traineeUsername, "traineeUsername");

        Trainee trainee = traineeRepository.findByUserUsername(traineeUsername)
                .orElseThrow(() -> {
                    LOGGER.warn("Trainee not found for trainer assignment username='{}'", traineeUsername);
                    return new ValidationException("Trainee not found by username: " + traineeUsername);
                });

        List<Trainer> trainers = trainerRepository.findByUsernameIn(trainerUsernames);
        if (trainerUsernames != null && trainers.size() != trainerUsernames.size()) {
            LOGGER.warn("Invalid trainer usernames for traineeUsername='{}'", traineeUsername);
            throw new ValidationException("One or more trainer usernames are invalid");
        }

        trainee.setTrainers(new HashSet<>(trainers));
        traineeRepository.save(trainee);

        LOGGER.info("Updated trainee trainers traineeUsername='{}' assignedTrainerCount={}",
                traineeUsername, trainers.size());
    }

    @Override
    public boolean existsByUsername(String username) {
        return traineeRepository.findByUserUsername(username).isPresent();
    }
}