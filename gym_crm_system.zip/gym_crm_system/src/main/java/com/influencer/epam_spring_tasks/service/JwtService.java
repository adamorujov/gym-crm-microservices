package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.model.User;

public interface JwtService {
    String generateToken(User user);
    String extractUsername(String token);
    boolean isTokenValid(String token, String username);
}