
package com.influencer.epam_spring_tasks.dto.request;

import java.time.LocalDate;

public class TrainerTrainingFilter {
    private String trainerUsername;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String traineeName;

    public String getTrainerUsername() {
        return trainerUsername;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public String getTraineeName() {
        return traineeName;
    }

    public void setTrainerUsername(String trainerUsername) {
        this.trainerUsername = trainerUsername;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    public void setTraineeName(String traineeName) {
        this.traineeName = traineeName;
    }
}