package com.influencer.epam_spring_tasks.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "trainings")
public class Training {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "trainee_id", nullable = false)
    private Trainee trainee;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "trainer_id", nullable = false)
    private Trainer trainer;

    @Column(name = "training_name", nullable = false, length = 150)
    private String trainingName;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "training_type_id", nullable = false)
    private TrainingType trainingType;

    @Column(name = "training_date", nullable = false)
    private LocalDate trainingDate;

    @Column(name = "training_duration", nullable = false)
    private Integer trainingDuration;

    public Long getId() {
        return id;
    }

    public Trainee getTrainee() {
        return trainee;
    }

    public Training setTrainee(Trainee trainee) {
        this.trainee = trainee;
        return this;
    }

    public Trainer getTrainer() {
        return trainer;
    }

    public Training setTrainer(Trainer trainer) {
        this.trainer = trainer;
        return this;
    }

    public String getTrainingName() {
        return trainingName;
    }

    public Training setTrainingName(String trainingName) {
        this.trainingName = trainingName;
        return this;
    }

    public TrainingType getTrainingType() {
        return trainingType;
    }

    public Training setTrainingType(TrainingType trainingType) {
        this.trainingType = trainingType;
        return this;
    }

    public LocalDate getTrainingDate() {
        return trainingDate;
    }

    public Training setTrainingDate(LocalDate trainingDate) {
        this.trainingDate = trainingDate;
        return this;
    }

    public Integer getTrainingDuration() {
        return trainingDuration;
    }

    public Training setTrainingDuration(Integer trainingDuration) {
        this.trainingDuration = trainingDuration;
        return this;
    }
}
