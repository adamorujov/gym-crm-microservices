
package com.influencer.epam_spring_tasks.storage;

import com.influencer.epam_spring_tasks.model.TrainingType;
import com.influencer.epam_spring_tasks.repository.TrainingTypeRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
public class TrainingTypeDataSeeder {

    private static final Logger LOGGER = LoggerFactory.getLogger(TrainingTypeDataSeeder.class);
    private final TrainingTypeRepository trainingTypeRepository;

    public TrainingTypeDataSeeder(TrainingTypeRepository trainingTypeRepository) {
        this.trainingTypeRepository = trainingTypeRepository;
    }

    @EventListener(ContextRefreshedEvent.class)
    @Transactional
    public void seed() {
        List<String> constants = List.of("Cardio", "Strength", "Yoga", "Pilates");

        for (String typeName : constants) {
            boolean exists = trainingTypeRepository.existsByTrainingTypeName(typeName);
            if (!exists) {
                TrainingType tt = new TrainingType();
                tt.setTrainingTypeName(typeName);
                trainingTypeRepository.save(tt);
                LOGGER.info("Seeded training type: {}", typeName);
            }
        }
    }
}