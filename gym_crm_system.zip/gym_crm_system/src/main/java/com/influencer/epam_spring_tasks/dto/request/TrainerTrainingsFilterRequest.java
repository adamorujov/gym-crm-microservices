package com.influencer.epam_spring_tasks.dto.request;

import java.time.LocalDate;

public class TrainerTrainingsFilterRequest {
    private String username;
    private LocalDate periodFrom;
    private LocalDate periodTo;
    private String traineeName;

    public String getUsername() {
        return username;
    }

    public TrainerTrainingsFilterRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public LocalDate getPeriodFrom() {
        return periodFrom;
    }

    public TrainerTrainingsFilterRequest setPeriodFrom(LocalDate periodFrom) {
        this.periodFrom = periodFrom;
        return this;
    }

    public LocalDate getPeriodTo() {
        return periodTo;
    }

    public TrainerTrainingsFilterRequest setPeriodTo(LocalDate periodTo) {
        this.periodTo = periodTo;
        return this;
    }

    public String getTraineeName() {
        return traineeName;
    }

    public TrainerTrainingsFilterRequest setTraineeName(String traineeName) {
        this.traineeName = traineeName;
        return this;
    }
}
