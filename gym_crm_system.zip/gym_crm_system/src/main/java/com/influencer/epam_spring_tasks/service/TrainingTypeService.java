package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.dto.response.TrainingTypeResponse;
import java.util.List;

public interface TrainingTypeService {
    List<TrainingTypeResponse> getTrainingTypes();
}