package com.influencer.epam_spring_tasks.service.impl;

import com.influencer.epam_spring_tasks.exception.AuthenticationException;
import com.influencer.epam_spring_tasks.model.User;
import com.influencer.epam_spring_tasks.repository.UserRepository;
import com.influencer.epam_spring_tasks.service.AuthenticationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthenticationServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean authenticate(String username, String password) {
        return userRepository.findByUsername(username)
                .map(user -> passwordEncoder.matches(password, user.getPassword()))
                .orElse(false);
    }

    @Override
    @Transactional(readOnly = true)
    public User requireAuthentication(String username, String password) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> {
                    LOGGER.warn("Authentication failed: username={} not found", username);
                    return new AuthenticationException("Invalid credentials");
                });

        if (!passwordEncoder.matches(password, user.getPassword())) {
            LOGGER.warn("Authentication failed: bad password for username={}", username);
            throw new AuthenticationException("Invalid credentials");
        }

        LOGGER.debug("Authentication successful for username={}", username);
        return user;
    }
}