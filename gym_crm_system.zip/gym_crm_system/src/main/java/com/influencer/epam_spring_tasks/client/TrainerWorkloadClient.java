package com.influencer.epam_spring_tasks.client;

import com.influencer.epam_spring_tasks.dto.workload.TrainerWorkloadRequest;
import com.influencer.epam_spring_tasks.dto.workload.TrainerWorkloadResponse;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "trainer-workload-service")
public interface TrainerWorkloadClient {

    @PostMapping("/api/trainer-workload/process")
    @CircuitBreaker(name = "trainerWorkloadService", fallbackMethod = "processWorkloadFallback")
    TrainerWorkloadResponse processTrainerWorkload(@RequestBody TrainerWorkloadRequest request);

    @GetMapping("/api/trainer-workload/trainer/{username}")
    @CircuitBreaker(name = "trainerWorkloadService", fallbackMethod = "getWorkloadFallback")
    Object getTrainerWorkload(@PathVariable String username);

    default TrainerWorkloadResponse processWorkloadFallback(TrainerWorkloadRequest request, Exception ex) {
        return new TrainerWorkloadResponse("ERROR", "Trainer workload service is currently unavailable: " + ex.getMessage());
    }

    default Object getWorkloadFallback(String username, Exception ex) {
        return new TrainerWorkloadResponse("ERROR", "Trainer workload service is currently unavailable: " + ex.getMessage());
    }
}

