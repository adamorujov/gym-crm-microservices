package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.dto.request.CreateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.request.TrainerTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.UpdateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import java.util.List;

public interface TrainerService {
    CredentialResponse createTrainer(CreateTrainerRequest request);
    TrainerResponse getTrainerByUsername(String username);
    TrainerResponse updateTrainer(UpdateTrainerRequest request);
    void changeTrainerPassword(String targetUsername, String newPassword);
    void activateTrainer(String username);
    void deactivateTrainer(String username);
    List<TrainingResponse> getTrainerTrainings(TrainerTrainingFilter filter);

    boolean existsByUsername(String username);
}