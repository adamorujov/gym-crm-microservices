
package com.influencer.epam_spring_tasks.service;

import com.influencer.epam_spring_tasks.model.User;

public interface AuthenticationService {
    boolean authenticate(String username, String password);
    User requireAuthentication(String username, String password);
}