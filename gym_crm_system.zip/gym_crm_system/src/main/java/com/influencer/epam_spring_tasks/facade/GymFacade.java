package com.influencer.epam_spring_tasks.facade;

import com.influencer.epam_spring_tasks.dto.request.ChangePasswordRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.TrainerTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.TrainingAddRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.dto.response.TraineeResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainerShortResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingResponse;
import com.influencer.epam_spring_tasks.dto.response.TrainingTypeResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.service.TraineeService;
import com.influencer.epam_spring_tasks.service.TrainerService;
import com.influencer.epam_spring_tasks.service.TrainingService;
import com.influencer.epam_spring_tasks.service.TrainingTypeService;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class GymFacade {

    private final TraineeService traineeService;
    private final TrainerService trainerService;
    private final TrainingService trainingService;
    private final TrainingTypeService trainingTypeService;

    public GymFacade(
            TraineeService traineeService,
            TrainerService trainerService,
            TrainingService trainingService,
            TrainingTypeService trainingTypeService
    ) {
        this.traineeService = traineeService;
        this.trainerService = trainerService;
        this.trainingService = trainingService;
        this.trainingTypeService = trainingTypeService;
    }

    public CredentialResponse createTrainer(CreateTrainerRequest request) {
        return trainerService.createTrainer(request);
    }

    public CredentialResponse createTrainee(CreateTraineeRequest request) {
        return traineeService.createTrainee(request);
    }

    public TrainerResponse getTrainerByUsername(String username) {
        return trainerService.getTrainerByUsername(username);
    }

    public TraineeResponse getTraineeByUsername(String username) {
        return traineeService.getTraineeByUsername(username);
    }

    public void changeTraineePassword(String targetUsername, String newPassword) {
        traineeService.changeTraineePassword(targetUsername, newPassword);
    }

    public void changeTrainerPassword(String targetUsername, String newPassword) {
        trainerService.changeTrainerPassword(targetUsername, newPassword);
    }

    public void changeUserPassword(ChangePasswordRequest request) {
        String username = request.getUsername();
        if (isTraineeUsername(username)) {
            changeTraineePassword(username, request.getNewPassword());
            return;
        }
        if (isTrainerUsername(username)) {
            changeTrainerPassword(username, request.getNewPassword());
            return;
        }
        throw new ValidationException("User not found");
    }

    public TrainerResponse updateTrainer(UpdateTrainerRequest request) {
        return trainerService.updateTrainer(request);
    }

    public TraineeResponse updateTrainee(UpdateTraineeRequest request) {
        return traineeService.updateTrainee(request);
    }

    public void activateTrainee(String username) {
        traineeService.activateTrainee(username);
    }

    public void deactivateTrainee(String username) {
        traineeService.deactivateTrainee(username);
    }

    public void activateTrainer(String username) {
        trainerService.activateTrainer(username);
    }

    public void deactivateTrainer(String username) {
        trainerService.deactivateTrainer(username);
    }

    public void deleteTraineeByUsername(String username) {
        traineeService.deleteTraineeByUsername(username);
    }

    public List<TrainingResponse> getTraineeTrainings(TraineeTrainingFilter filter) {
        return traineeService.getTraineeTrainings(filter);
    }

    public List<TrainingResponse> getTrainerTrainings(TrainerTrainingFilter filter) {
        return trainerService.getTrainerTrainings(filter);
    }

    public TrainingResponse addTraining(TrainingAddRequest request) {
        return trainingService.addTraining(request);
    }

    public List<TrainerShortResponse> getUnassignedTrainersByTraineeUsername(String traineeUsername) {
        return traineeService.getUnassignedTrainersByTraineeUsername(traineeUsername);
    }

    public void updateTraineeTrainers(String traineeUsername, List<String> trainerUsernames) {
        traineeService.updateTraineeTrainers(traineeUsername, trainerUsernames);
    }

    public List<TrainingTypeResponse> getTrainingTypes() {
        return trainingTypeService.getTrainingTypes();
    }

    public boolean isTraineeUsername(String username) {
        return traineeService.existsByUsername(username);
    }

    public boolean isTrainerUsername(String username) {
        return trainerService.existsByUsername(username);
    }
}