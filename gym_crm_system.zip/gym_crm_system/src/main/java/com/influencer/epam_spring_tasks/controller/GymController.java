package com.influencer.epam_spring_tasks.controller;

import com.influencer.epam_spring_tasks.dto.request.ChangePasswordRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.CreateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeRegistrationRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainerListUpdateRequest;
import com.influencer.epam_spring_tasks.dto.request.TraineeTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.TrainerRegistrationRequest;
import com.influencer.epam_spring_tasks.dto.request.TrainerTrainingFilter;
import com.influencer.epam_spring_tasks.dto.request.TrainingAddRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTraineeRequest;
import com.influencer.epam_spring_tasks.dto.request.UpdateTrainerRequest;
import com.influencer.epam_spring_tasks.dto.response.AuthResponse;
import com.influencer.epam_spring_tasks.dto.response.CredentialResponse;
import com.influencer.epam_spring_tasks.exception.ValidationException;
import com.influencer.epam_spring_tasks.facade.GymFacade;
import com.influencer.epam_spring_tasks.monitoring.metrics.GymMetricsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@Api(tags = "Gym CRM API")
public class GymController {

    private static final Logger LOGGER = LoggerFactory.getLogger(GymController.class);

    private final GymFacade gymFacade;
    private final GymMetricsService gymMetricsService;

    public GymController(GymFacade gymFacade, GymMetricsService gymMetricsService) {
        this.gymFacade = gymFacade;
        this.gymMetricsService = gymMetricsService;
    }

    @ModelAttribute
    public void initTransactionId() {
        MDC.put("transactionId", UUID.randomUUID().toString());
    }

    // ==================== PUBLIC REGISTRATION ====================

    @ApiOperation(value = "Register trainee")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Trainee registered successfully"),
            @ApiResponse(code = 400, message = "Invalid request")
    })
    @PostMapping("/trainees")
    public ResponseEntity<CredentialResponse> registerTrainee(@Valid @RequestBody TraineeRegistrationRequest request) {
        LOGGER.info("Registering trainee: {} {}", request.getFirstName(), request.getLastName());

        CreateTraineeRequest serviceRequest = new CreateTraineeRequest();
        serviceRequest.setFirstName(request.getFirstName());
        serviceRequest.setLastName(request.getLastName());
        serviceRequest.setDateOfBirth(request.getDateOfBirth());
        serviceRequest.setAddress(request.getAddress());

        CredentialResponse response = gymFacade.createTrainee(serviceRequest);
        gymMetricsService.incrementTraineeRegistrations();

        LOGGER.info("Trainee registered successfully: {}", response.getUsername());
        return ResponseEntity.ok(response);
    }

    @ApiOperation(value = "Register trainer")
    @ApiResponses({
            @ApiResponse(code = 200, message = "Trainer registered successfully"),
            @ApiResponse(code = 400, message = "Invalid request")
    })
    @PostMapping("/trainers")
    public ResponseEntity<CredentialResponse> registerTrainer(@Valid @RequestBody TrainerRegistrationRequest request) {
        LOGGER.info("Registering trainer: {} {}", request.getFirstName(), request.getLastName());

        CreateTrainerRequest serviceRequest = new CreateTrainerRequest();
        serviceRequest.setFirstName(request.getFirstName());
        serviceRequest.setLastName(request.getLastName());
        serviceRequest.setSpecializationTypeName(request.getSpecialization());

        CredentialResponse response = gymFacade.createTrainer(serviceRequest);
        gymMetricsService.incrementTrainerRegistrations();

        LOGGER.info("Trainer registered successfully: {}", response.getUsername());
        return ResponseEntity.ok(response);
    }

    // ==================== PROFILE ====================

    @ApiOperation(value = "Get trainee profile by username")
    @GetMapping("/trainees/{username}")
    public ResponseEntity<?> getTraineeProfile(@PathVariable String username) {
        LOGGER.debug("Getting trainee profile for: {}", username);
        return ResponseEntity.ok(gymFacade.getTraineeByUsername(username));
    }

    @ApiOperation(value = "Update trainee profile")
    @PutMapping("/trainees/{username}")
    public ResponseEntity<?> updateTraineeProfile(
            @PathVariable String username,
            @Valid @RequestBody UpdateTraineeRequest request) {
        LOGGER.info("Updating trainee profile for: {}", username);
        request.setTargetUsername(username);
        return ResponseEntity.ok(gymFacade.updateTrainee(request));
    }

    @ApiOperation(value = "Delete trainee by username")
    @DeleteMapping("/trainees/{username}")
    public ResponseEntity<AuthResponse> deleteTrainee(@PathVariable String username) {
        LOGGER.info("Deleting trainee: {}", username);
        gymFacade.deleteTraineeByUsername(username);
        return ResponseEntity.ok(new AuthResponse("OK", "Trainee deleted"));
    }

    @ApiOperation(value = "Get trainer profile by username")
    @GetMapping("/trainers/{username}")
    public ResponseEntity<?> getTrainerProfile(@PathVariable String username) {
        LOGGER.debug("Getting trainer profile for: {}", username);
        return ResponseEntity.ok(gymFacade.getTrainerByUsername(username));
    }

    @ApiOperation(value = "Update trainer profile")
    @PutMapping("/trainers/{username}")
    public ResponseEntity<?> updateTrainerProfile(
            @PathVariable String username,
            @Valid @RequestBody UpdateTrainerRequest request) {
        LOGGER.info("Updating trainer profile for: {}", username);
        request.setTargetUsername(username);
        return ResponseEntity.ok(gymFacade.updateTrainer(request));
    }

    // ==================== PASSWORD ====================

    @ApiOperation(value = "Change password")
    @PutMapping("/login")
    public ResponseEntity<AuthResponse> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        if (request == null
                || isBlank(request.getUsername())
                || isBlank(request.getOldPassword())
                || isBlank(request.getNewPassword())) {
            return ResponseEntity.badRequest().body(new AuthResponse("ERROR", "Invalid request"));
        }

        // NOTE: oldPassword validation should happen in your auth/login module.
        try {
            gymFacade.changeUserPassword(request);
            return ResponseEntity.ok(new AuthResponse("OK", "Password changed"));
        } catch (ValidationException ex) {
            if ("User not found".equalsIgnoreCase(ex.getMessage())) {
                return ResponseEntity.status(404).body(new AuthResponse("ERROR", "User not found"));
            }
            return ResponseEntity.badRequest().body(new AuthResponse("ERROR", ex.getMessage()));
        }
    }

    // ==================== ACTIVATE / DEACTIVATE ====================

    @PatchMapping("/trainees/{username}/activate")
    public ResponseEntity<AuthResponse> activateTrainee(@PathVariable String username) {
        gymFacade.activateTrainee(username);
        return ResponseEntity.ok(new AuthResponse("OK", "Trainee activated"));
    }

    @PatchMapping("/trainees/{username}/deactivate")
    public ResponseEntity<AuthResponse> deactivateTrainee(@PathVariable String username) {
        gymFacade.deactivateTrainee(username);
        return ResponseEntity.ok(new AuthResponse("OK", "Trainee deactivated"));
    }

    @PatchMapping("/trainers/{username}/activate")
    public ResponseEntity<AuthResponse> activateTrainer(@PathVariable String username) {
        gymFacade.activateTrainer(username);
        return ResponseEntity.ok(new AuthResponse("OK", "Trainer activated"));
    }

    @PatchMapping("/trainers/{username}/deactivate")
    public ResponseEntity<AuthResponse> deactivateTrainer(@PathVariable String username) {
        gymFacade.deactivateTrainer(username);
        return ResponseEntity.ok(new AuthResponse("OK", "Trainer deactivated"));
    }

    // ==================== TRAININGS ====================

    @GetMapping("/trainees/{username}/trainings")
    public ResponseEntity<List<?>> getTraineeTrainings(
            @PathVariable String username,
            @RequestParam(required = false) String periodFrom,
            @RequestParam(required = false) String periodTo,
            @RequestParam(required = false) String trainerName,
            @RequestParam(required = false) String trainingType) {

        TraineeTrainingFilter filter = new TraineeTrainingFilter();
        filter.setTraineeUsername(username);
        filter.setFromDate(periodFrom != null ? LocalDate.parse(periodFrom) : null);
        filter.setToDate(periodTo != null ? LocalDate.parse(periodTo) : null);
        filter.setTrainerName(trainerName);
        filter.setTrainingTypeName(trainingType);

        return ResponseEntity.ok((List<?>) gymFacade.getTraineeTrainings(filter));
    }

    @GetMapping("/trainers/{username}/trainings")
    public ResponseEntity<List<?>> getTrainerTrainings(
            @PathVariable String username,
            @RequestParam(required = false) String periodFrom,
            @RequestParam(required = false) String periodTo,
            @RequestParam(required = false) String traineeName) {

        TrainerTrainingFilter filter = new TrainerTrainingFilter();
        filter.setTrainerUsername(username);
        filter.setFromDate(periodFrom != null ? LocalDate.parse(periodFrom) : null);
        filter.setToDate(periodTo != null ? LocalDate.parse(periodTo) : null);
        filter.setTraineeName(traineeName);

        return ResponseEntity.ok((List<?>) gymFacade.getTrainerTrainings(filter));
    }

    @PostMapping("/trainings")
    public ResponseEntity<?> addTraining(@Valid @RequestBody TrainingAddRequest request) {
        Object training = gymFacade.addTraining(request);
        gymMetricsService.incrementTrainingsCreated();
        return ResponseEntity.ok(training);
    }

    // ==================== TRAINEE-TRAINER ASSIGNMENT ====================

    @GetMapping("/trainees/{username}/unassigned-trainers")
    public ResponseEntity<?> getUnassignedTrainers(@PathVariable String username) {
        return ResponseEntity.ok(gymFacade.getUnassignedTrainersByTraineeUsername(username));
    }

    @PutMapping("/trainees/{username}/trainers")
    public ResponseEntity<AuthResponse> updateTraineeTrainers(
            @PathVariable String username,
            @Valid @RequestBody TraineeTrainerListUpdateRequest request) {

        if (request == null
                || request.getTrainerUsernames() == null
                || request.getTrainerUsernames().isEmpty()
                || request.getTrainerUsernames().stream().anyMatch(this::isBlank)) {
            return ResponseEntity.badRequest().body(new AuthResponse("ERROR", "Invalid request"));
        }

        gymFacade.updateTraineeTrainers(username, request.getTrainerUsernames());
        gymMetricsService.incrementTraineeTrainerUpdates();
        return ResponseEntity.ok(new AuthResponse("OK", "Trainee trainer list updated"));
    }

    // ==================== TRAINING TYPES ====================

    @GetMapping("/training-types")
    public ResponseEntity<?> getTrainingTypes() {
        return ResponseEntity.ok(gymFacade.getTrainingTypes());
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}