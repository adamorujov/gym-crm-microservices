package com.influencer.epam_spring_tasks.dto.request;

import jakarta.validation.constraints.NotBlank;

public class TrainerProfileUpdateRequest {
    @NotBlank(message = "Username cannot be blank")
    private String username;
    @NotBlank(message = "First name cannot be blank")
    private String firstName;
    @NotBlank(message = "Last name cannot be blank")
    private String lastName;
    private String specialization;
    private Boolean isActive;

    public String getUsername() {
        return username;
    }

    public TrainerProfileUpdateRequest setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getFirstName() {
        return firstName;
    }

    public TrainerProfileUpdateRequest setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public TrainerProfileUpdateRequest setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getSpecialization() {
        return specialization;
    }

    public TrainerProfileUpdateRequest setSpecialization(String specialization) {
        this.specialization = specialization;
        return this;
    }

    public Boolean getActive() {
        return isActive;
    }

    public TrainerProfileUpdateRequest setActive(Boolean active) {
        isActive = active;
        return this;
    }
}
